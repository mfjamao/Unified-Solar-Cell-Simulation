DF-ISE text

Info {
  version   = 1.0
  type      = xyplot
  datasets  = [
    "time"
    "c1 OuterVoltage" "c1 InnerVoltage" "c1 QuasiFermiPotential" "c1 DisplacementCurrent" "c1 eCurrent"
    "c1 hCurrent" "c1 TotalCurrent" "c1 Charge" "c2 OuterVoltage" "c2 InnerVoltage"
    "c2 QuasiFermiPotential" "c2 DisplacementCurrent" "c2 eCurrent" "c2 hCurrent" "c2 TotalCurrent"
    "c2 Charge" "Device=,File=CommandFile/Physics,DefaultRegionPhysics,ModelParameter=Optics/Excitation/Wavelength" "IntegrSemiconductor OpticalGeneration" "IntegrSemiconductor OpticalGenerationFromMonochromaticSource" "IntegrSemiconductor OpticalGenerationFromSpectrum"
    "IntegrSemiconductor OpticalGenerationFromSpectrumUnscaled" "AveSemiconductor OpticalGeneration" "AveSemiconductor OpticalGenerationFromMonochromaticSource" "AveSemiconductor OpticalGenerationFromSpectrum" "AveSemiconductor OpticalGenerationFromSpectrumUnscaled"
    "Integr03_CdS OpticalGeneration" "Integr03_CdS OpticalGenerationFromMonochromaticSource" "Integr03_CdS OpticalGenerationFromSpectrum" "Integr03_CdS OpticalGenerationFromSpectrumUnscaled" "Integr04_ZnSe OpticalGeneration"
    "Integr04_ZnSe OpticalGenerationFromMonochromaticSource" "Integr04_ZnSe OpticalGenerationFromSpectrum" "Integr04_ZnSe OpticalGenerationFromSpectrumUnscaled" "Integr05_CZTSe OpticalGeneration" "Integr05_CZTSe OpticalGenerationFromMonochromaticSource"
    "Integr05_CZTSe OpticalGenerationFromSpectrum" "Integr05_CZTSe OpticalGenerationFromSpectrumUnscaled" "Integr06_CZTSe OpticalGeneration" "Integr06_CZTSe OpticalGenerationFromMonochromaticSource" "Integr06_CZTSe OpticalGenerationFromSpectrum"
    "Integr06_CZTSe OpticalGenerationFromSpectrumUnscaled" "Integr07_CZTSe OpticalGeneration" "Integr07_CZTSe OpticalGenerationFromMonochromaticSource" "Integr07_CZTSe OpticalGenerationFromSpectrum" "Integr07_CZTSe OpticalGenerationFromSpectrumUnscaled"
    "Integr08_CZTSe OpticalGeneration" "Integr08_CZTSe OpticalGenerationFromMonochromaticSource" "Integr08_CZTSe OpticalGenerationFromSpectrum" "Integr08_CZTSe OpticalGenerationFromSpectrumUnscaled" "Integr09_CZTSe OpticalGeneration"
    "Integr09_CZTSe OpticalGenerationFromMonochromaticSource" "Integr09_CZTSe OpticalGenerationFromSpectrum" "Integr09_CZTSe OpticalGenerationFromSpectrumUnscaled" "IntegrSemiconductor AbsorbedPhotonDensity" "IntegrSemiconductor AbsorbedPhotonDensityFromMonochromaticSource"
    "IntegrSemiconductor AbsorbedPhotonDensityFromSpectrum" "Integr AbsorbedPhotonDensity" "Integr AbsorbedPhotonDensityFromMonochromaticSource" "Integr AbsorbedPhotonDensityFromSpectrum" "Integr01_AZO AbsorbedPhotonDensity"
    "Integr01_AZO AbsorbedPhotonDensityFromMonochromaticSource" "Integr01_AZO AbsorbedPhotonDensityFromSpectrum" "Integr02_IZO AbsorbedPhotonDensity" "Integr02_IZO AbsorbedPhotonDensityFromMonochromaticSource" "Integr02_IZO AbsorbedPhotonDensityFromSpectrum"
    "Integr03_CdS AbsorbedPhotonDensity" "Integr03_CdS AbsorbedPhotonDensityFromMonochromaticSource" "Integr03_CdS AbsorbedPhotonDensityFromSpectrum" "Integr04_ZnSe AbsorbedPhotonDensity" "Integr04_ZnSe AbsorbedPhotonDensityFromMonochromaticSource"
    "Integr04_ZnSe AbsorbedPhotonDensityFromSpectrum" "Integr05_CZTSe AbsorbedPhotonDensity" "Integr05_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr05_CZTSe AbsorbedPhotonDensityFromSpectrum" "Integr06_CZTSe AbsorbedPhotonDensity"
    "Integr06_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr06_CZTSe AbsorbedPhotonDensityFromSpectrum" "Integr07_CZTSe AbsorbedPhotonDensity" "Integr07_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr07_CZTSe AbsorbedPhotonDensityFromSpectrum"
    "Integr08_CZTSe AbsorbedPhotonDensity" "Integr08_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr08_CZTSe AbsorbedPhotonDensityFromSpectrum" "Integr09_CZTSe AbsorbedPhotonDensity" "Integr09_CZTSe AbsorbedPhotonDensityFromMonochromaticSource"
    "Integr09_CZTSe AbsorbedPhotonDensityFromSpectrum" "IntegrSemiconductor AugerRecombination" "Integr03_CdS AugerRecombination" "Integr04_ZnSe AugerRecombination" "Integr05_CZTSe AugerRecombination"
    "Integr06_CZTSe AugerRecombination" "Integr07_CZTSe AugerRecombination" "Integr08_CZTSe AugerRecombination" "Integr09_CZTSe AugerRecombination" "IntegrSemiconductor RadiativeRecombination"
    "Integr03_CdS RadiativeRecombination" "Integr04_ZnSe RadiativeRecombination" "Integr05_CZTSe RadiativeRecombination" "Integr06_CZTSe RadiativeRecombination" "Integr07_CZTSe RadiativeRecombination"
    "Integr08_CZTSe RadiativeRecombination" "Integr09_CZTSe RadiativeRecombination" "IntegrSemiconductor eGapStatesRecombination" "Integr03_CdS eGapStatesRecombination" "Integr04_ZnSe eGapStatesRecombination"
    "Integr05_CZTSe eGapStatesRecombination" "Integr06_CZTSe eGapStatesRecombination" "Integr07_CZTSe eGapStatesRecombination" "Integr08_CZTSe eGapStatesRecombination" "Integr09_CZTSe eGapStatesRecombination"
    "IntegrSemiconductor PMIRecombination" "Integr03_CdS PMIRecombination" "Integr04_ZnSe PMIRecombination" "Integr05_CZTSe PMIRecombination" "Integr06_CZTSe PMIRecombination"
    "Integr07_CZTSe PMIRecombination" "Integr08_CZTSe PMIRecombination" "Integr09_CZTSe PMIRecombination" "IntegrSemiconductor srhRecombination" "Integr03_CdS srhRecombination"
    "Integr04_ZnSe srhRecombination" "Integr05_CZTSe srhRecombination" "Integr06_CZTSe srhRecombination" "Integr07_CZTSe srhRecombination" "Integr08_CZTSe srhRecombination"
    "Integr09_CZTSe srhRecombination" "IntegrSemiconductor TotalRecombination" "Integr03_CdS TotalRecombination" "Integr04_ZnSe TotalRecombination" "Integr05_CZTSe TotalRecombination"
    "Integr06_CZTSe TotalRecombination" "Integr07_CZTSe TotalRecombination" "Integr08_CZTSe TotalRecombination" "Integr09_CZTSe TotalRecombination" "Ave03_CdS eDensity"
    "Ave04_ZnSe eDensity" "Ave05_CZTSe eDensity" "Ave06_CZTSe eDensity" "Ave07_CZTSe eDensity" "Ave08_CZTSe eDensity"
    "Ave09_CZTSe eDensity" "Ave03_CdS EffectiveIntrinsicDensity" "Ave04_ZnSe EffectiveIntrinsicDensity" "Ave05_CZTSe EffectiveIntrinsicDensity" "Ave06_CZTSe EffectiveIntrinsicDensity"
    "Ave07_CZTSe EffectiveIntrinsicDensity" "Ave08_CZTSe EffectiveIntrinsicDensity" "Ave09_CZTSe EffectiveIntrinsicDensity" "Ave03_CdS hDensity" "Ave04_ZnSe hDensity"
    "Ave05_CZTSe hDensity" "Ave06_CZTSe hDensity" "Ave07_CZTSe hDensity" "Ave08_CZTSe hDensity" "Ave09_CZTSe hDensity"
    "Integr04_ZnSe/05_CZTSe SurfaceRecombination" "Integr05_CZTSe/11_Gas SurfaceRecombination" "Integr05_CZTSe/12_Gas SurfaceRecombination" "Integr05_CZTSe/13_Gas SurfaceRecombination" "Integr05_CZTSe/14_Gas SurfaceRecombination"
    "Integr05_CZTSe/06_CZTSe SurfaceRecombination" "Integr05_CZTSe/07_CZTSe SurfaceRecombination" "Integr05_CZTSe/08_CZTSe SurfaceRecombination" "Integr05_CZTSe/09_CZTSe SurfaceRecombination" "Integr06_CZTSe/11_Gas SurfaceRecombination"
    "Integr06_CZTSe/13_Gas SurfaceRecombination" "Integr06_CZTSe/07_CZTSe SurfaceRecombination" "Integr06_CZTSe/08_CZTSe SurfaceRecombination" "Integr07_CZTSe/11_Gas SurfaceRecombination" "Integr07_CZTSe/14_Gas SurfaceRecombination"
    "Integr08_CZTSe/12_Gas SurfaceRecombination" "Integr08_CZTSe/13_Gas SurfaceRecombination" "Integr09_CZTSe/12_Gas SurfaceRecombination" "Integr09_CZTSe/14_Gas SurfaceRecombination" "Integr09_CZTSe/07_CZTSe SurfaceRecombination"
    "Integr09_CZTSe/08_CZTSe SurfaceRecombination" ]
  functions = [
    Time
    OuterVoltage InnerVoltage QuasiFermiPotential DisplacementCurrent eCurrent
    hCurrent TotalCurrent Charge OuterVoltage InnerVoltage
    QuasiFermiPotential DisplacementCurrent eCurrent hCurrent TotalCurrent
    Charge ModelParameter OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AugerRecombination AugerRecombination AugerRecombination AugerRecombination
    AugerRecombination AugerRecombination AugerRecombination AugerRecombination RadiativeRecombination
    RadiativeRecombination RadiativeRecombination RadiativeRecombination RadiativeRecombination RadiativeRecombination
    RadiativeRecombination RadiativeRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination
    eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination
    PMIRecombination PMIRecombination PMIRecombination PMIRecombination PMIRecombination
    PMIRecombination PMIRecombination PMIRecombination srhRecombination srhRecombination
    srhRecombination srhRecombination srhRecombination srhRecombination srhRecombination
    srhRecombination TotalRecombination TotalRecombination TotalRecombination TotalRecombination
    TotalRecombination TotalRecombination TotalRecombination TotalRecombination eDensity
    eDensity eDensity eDensity eDensity eDensity
    eDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity
    EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity hDensity hDensity
    hDensity hDensity hDensity hDensity hDensity
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination ]
}

Data {
      0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   1.10862553709062E-12
     -1.11042399511722E-10  -1.09933773974631E-10  -5.01467702974780E-18   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   1.09933774046366E-10   0.00000000000000E+00   1.09933774046366E-10
      5.01467702975021E-18   3.00000000000000E-01   7.37417315982258E+08   0.00000000000000E+00   7.37417315982258E+08
      2.45805771994081E+09   4.53795271374345E+20   0.00000000000000E+00   4.53795271374345E+20   1.51265090458112E+21
      2.46512387399427E+07   0.00000000000000E+00   2.46512387399427E+07   8.21707957998149E+07   7.76077294286930E+03
      0.00000000000000E+00   7.76077294286930E+03   2.58692431428934E+04   7.07016953366761E+08   0.00000000000000E+00
      7.07016953366761E+08   2.35672317788917E+09   1.28212434798866E+06   0.00000000000000E+00   1.28212434798866E+06
      4.27374782662877E+06   1.48641291824129E+06   0.00000000000000E+00   1.48641291824129E+06   4.95470972747106E+06
      1.48641291824129E+06   0.00000000000000E+00   1.48641291824129E+06   4.95470972747105E+06   1.48641291824128E+06
      0.00000000000000E+00   1.48641291824128E+06   4.95470972747104E+06   2.45867855971091E+09   6.20839770852855E+05
      2.45805771994081E+09   3.10690062195261E+09   1.86290479931738E+07   3.08827157396051E+09   4.36610366047549E+08
      1.39719173432176E+07   4.22638448704358E+08   2.24337534830441E+07   8.91834316634722E+05   2.15419191664117E+07
      8.23597023104999E+07   1.88906510686213E+05   8.21707957998149E+07   2.60291803432018E+04   1.59937200305876E+02
      2.58692431428934E+04   2.35715477909434E+09   4.31601205908603E+05   2.35672317788917E+09   4.27378352644967E+06
      3.56998210119260E+01   4.27374782662877E+06   4.95475519988317E+06   4.54724122553985E+01   4.95470972747106E+06
      4.95475519988320E+06   4.54724122553987E+01   4.95470972747105E+06   4.95475519988317E+06   4.54724122553987E+01
      4.95470972747104E+06   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   3.43080549645046E+07   2.42525512467251E+07
      7.59210082107072E+03   9.84251146025838E+06   5.06643250406883E+04   5.15267413234314E+04   5.14837851714806E+04
      5.17253051681967E+04  -7.03104773496526E+08  -3.98687493219028E+05  -1.68672119442821E+02  -6.97172320521508E+08
     -1.23087542740688E+06  -1.43429054232207E+06  -1.43433739776325E+06  -1.43409344218292E+06   2.27598669202357E+16
      1.46902784527762E+13   3.04949638200758E+15   6.07973335435349E+09   6.18322349045416E+09   6.17806874350355E+09
      6.20705119383275E+09   3.24049831516134E-02   7.68680165220533E-05   2.77074907586036E+09   2.77074907585569E+09
      2.77074907585568E+09   2.77074907585566E+09   2.77074907585562E+09   1.21262756272474E+06   1.51842016442982E+03
      7.68690967628498E+14   1.79913584166148E+15   1.79913590283379E+15   1.79913570462601E+15   1.79913559816078E+15
      5.72498005600483E+04   1.48215314626075E+06   1.42129916085677E+06   1.42981988196346E+06   1.43553273816503E+06
      5.50991290953634E+05   5.62489010417693E+05   5.63951318244143E+05   5.66265775045048E+05   1.85752189893517E+05
      1.49493407207002E+05   3.10470672609319E+05   3.08872542270797E+05   1.82364812413981E+05   1.53173565552303E+05
      1.75047905595250E+05   1.74052670143900E+05   1.65774523753431E+05   1.75311129824208E+05   3.12063414118778E+05
      3.11978712407686E+05
      1.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   1.10871149110668E-12
     -1.11110171376881E-10  -1.10001459885774E-10  -5.01467770520766E-18   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   1.10001460133166E-10   0.00000000000000E+00   1.10001460133166E-10
      5.01467770520544E-18   3.00000000000000E-01   7.38038155753693E+08   6.20839770852855E+05   7.37417315982258E+08
      2.45805771994081E+09   4.54177326618305E+20   3.82055243602303E+17   4.53795271374345E+20   1.51265090458112E+21
      2.48401452506318E+07   1.88906510686213E+05   2.46512387399427E+07   8.21707957998149E+07   7.92071014317407E+03
      1.59937200305876E+02   7.76077294286930E+03   2.58692431428934E+04   7.07448554572784E+08   4.31601205908603E+05
      7.07016953366761E+08   2.35672317788917E+09   1.28216004780960E+06   3.56998210119260E+01   1.28212434798866E+06
      4.27374782662877E+06   1.48645839065352E+06   4.54724122553985E+01   1.48641291824129E+06   4.95470972747106E+06
      1.48645839065351E+06   4.54724122553987E+01   1.48641291824129E+06   4.95470972747105E+06   1.48645839065351E+06
      4.54724122553987E+01   1.48641291824128E+06   4.95470972747104E+06   2.45867855971091E+09   6.20839770852855E+05
      2.45805771994081E+09   3.10690062195261E+09   1.86290479931738E+07   3.08827157396051E+09   4.36610366047549E+08
      1.39719173432176E+07   4.22638448704358E+08   2.24337534830441E+07   8.91834316634722E+05   2.15419191664117E+07
      8.23597023104999E+07   1.88906510686213E+05   8.21707957998149E+07   2.60291803432018E+04   1.59937200305876E+02
      2.58692431428934E+04   2.35715477909434E+09   4.31601205908603E+05   2.35672317788917E+09   4.27378352644967E+06
      3.56998210119260E+01   4.27374782662877E+06   4.95475519988317E+06   4.54724122553985E+01   4.95470972747106E+06
      4.95475519988320E+06   4.54724122553987E+01   4.95470972747105E+06   4.95475519988317E+06   4.54724122553987E+01
      4.95470972747104E+06   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   3.44999666378417E+07   2.44379256393411E+07
      7.74844658234010E+03   9.84887416290360E+06   5.06688498897204E+04   5.15313077567474E+04   5.14883495221371E+04
      5.17298818477204E+04  -7.03533700901255E+08  -4.02219611289542E+05  -1.72263558430846E+02  -6.97597558551457E+08
     -1.23090654781384E+06  -1.43433139312951E+06  -1.43437825100183E+06  -1.43413428299698E+06   2.27598646225705E+16
      1.46902721936364E+13   3.04949680112617E+15   6.08027633718753E+09   6.18377146341281E+09   6.17861646654254E+09
      6.20760039633873E+09   3.24049831516134E-02   7.68680165220533E-05   2.77074907586036E+09   2.77074907585569E+09
      2.77074907585568E+09   2.77074907585566E+09   2.77074907585562E+09   1.22189628236092E+06   1.54968931669266E+03
      7.68691051137834E+14   1.79913584204850E+15   1.79913590322528E+15   1.79913570501697E+15   1.79913559855302E+15
      5.73002681201940E+04   1.48266292651272E+06   1.42180264966128E+06   1.43032445442138E+06   1.43603768601024E+06
      5.51045528449153E+05   5.62543763048475E+05   5.64006230568967E+05   5.66320779645691E+05   1.85769075882913E+05
      1.49506892917900E+05   3.10498691842674E+05   3.08900406753181E+05   1.82381266081406E+05   1.53187226130316E+05
      1.75063557736626E+05   1.74068271126072E+05   1.65789325531562E+05   1.75326792290167E+05   3.12091429255792E+05
      3.12006723939057E+05
}
