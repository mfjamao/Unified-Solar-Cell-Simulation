DF-ISE text

Info {
  version   = 1.0
  type      = xyplot
  datasets  = [
    "time"
    "c1 OuterVoltage" "c1 InnerVoltage" "c1 QuasiFermiPotential" "c1 DisplacementCurrent" "c1 eCurrent"
    "c1 hCurrent" "c1 TotalCurrent" "c1 Charge" "c2 OuterVoltage" "c2 InnerVoltage"
    "c2 QuasiFermiPotential" "c2 DisplacementCurrent" "c2 eCurrent" "c2 hCurrent" "c2 TotalCurrent"
    "c2 Charge" "Device=,File=CommandFile/Physics,DefaultRegionPhysics,ModelParameter=Optics/Excitation/Wavelength" "IntegrSemiconductor OpticalGeneration" "IntegrSemiconductor OpticalGenerationFromMonochromaticSource" "IntegrSemiconductor OpticalGenerationFromSpectrum"
    "IntegrSemiconductor OpticalGenerationFromSpectrumUnscaled" "AveSemiconductor OpticalGeneration" "AveSemiconductor OpticalGenerationFromMonochromaticSource" "AveSemiconductor OpticalGenerationFromSpectrum" "AveSemiconductor OpticalGenerationFromSpectrumUnscaled"
    "Integr03_CdS OpticalGeneration" "Integr03_CdS OpticalGenerationFromMonochromaticSource" "Integr03_CdS OpticalGenerationFromSpectrum" "Integr03_CdS OpticalGenerationFromSpectrumUnscaled" "Integr04_ZnSe OpticalGeneration"
    "Integr04_ZnSe OpticalGenerationFromMonochromaticSource" "Integr04_ZnSe OpticalGenerationFromSpectrum" "Integr04_ZnSe OpticalGenerationFromSpectrumUnscaled" "Integr05_CZTSe OpticalGeneration" "Integr05_CZTSe OpticalGenerationFromMonochromaticSource"
    "Integr05_CZTSe OpticalGenerationFromSpectrum" "Integr05_CZTSe OpticalGenerationFromSpectrumUnscaled" "Integr06_CZTSe OpticalGeneration" "Integr06_CZTSe OpticalGenerationFromMonochromaticSource" "Integr06_CZTSe OpticalGenerationFromSpectrum"
    "Integr06_CZTSe OpticalGenerationFromSpectrumUnscaled" "Integr07_CZTSe OpticalGeneration" "Integr07_CZTSe OpticalGenerationFromMonochromaticSource" "Integr07_CZTSe OpticalGenerationFromSpectrum" "Integr07_CZTSe OpticalGenerationFromSpectrumUnscaled"
    "Integr08_CZTSe OpticalGeneration" "Integr08_CZTSe OpticalGenerationFromMonochromaticSource" "Integr08_CZTSe OpticalGenerationFromSpectrum" "Integr08_CZTSe OpticalGenerationFromSpectrumUnscaled" "Integr09_CZTSe OpticalGeneration"
    "Integr09_CZTSe OpticalGenerationFromMonochromaticSource" "Integr09_CZTSe OpticalGenerationFromSpectrum" "Integr09_CZTSe OpticalGenerationFromSpectrumUnscaled" "IntegrSemiconductor AbsorbedPhotonDensity" "IntegrSemiconductor AbsorbedPhotonDensityFromMonochromaticSource"
    "IntegrSemiconductor AbsorbedPhotonDensityFromSpectrum" "Integr AbsorbedPhotonDensity" "Integr AbsorbedPhotonDensityFromMonochromaticSource" "Integr AbsorbedPhotonDensityFromSpectrum" "Integr01_AZO AbsorbedPhotonDensity"
    "Integr01_AZO AbsorbedPhotonDensityFromMonochromaticSource" "Integr01_AZO AbsorbedPhotonDensityFromSpectrum" "Integr02_IZO AbsorbedPhotonDensity" "Integr02_IZO AbsorbedPhotonDensityFromMonochromaticSource" "Integr02_IZO AbsorbedPhotonDensityFromSpectrum"
    "Integr03_CdS AbsorbedPhotonDensity" "Integr03_CdS AbsorbedPhotonDensityFromMonochromaticSource" "Integr03_CdS AbsorbedPhotonDensityFromSpectrum" "Integr04_ZnSe AbsorbedPhotonDensity" "Integr04_ZnSe AbsorbedPhotonDensityFromMonochromaticSource"
    "Integr04_ZnSe AbsorbedPhotonDensityFromSpectrum" "Integr05_CZTSe AbsorbedPhotonDensity" "Integr05_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr05_CZTSe AbsorbedPhotonDensityFromSpectrum" "Integr06_CZTSe AbsorbedPhotonDensity"
    "Integr06_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr06_CZTSe AbsorbedPhotonDensityFromSpectrum" "Integr07_CZTSe AbsorbedPhotonDensity" "Integr07_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr07_CZTSe AbsorbedPhotonDensityFromSpectrum"
    "Integr08_CZTSe AbsorbedPhotonDensity" "Integr08_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr08_CZTSe AbsorbedPhotonDensityFromSpectrum" "Integr09_CZTSe AbsorbedPhotonDensity" "Integr09_CZTSe AbsorbedPhotonDensityFromMonochromaticSource"
    "Integr09_CZTSe AbsorbedPhotonDensityFromSpectrum" "IntegrSemiconductor AugerRecombination" "Integr03_CdS AugerRecombination" "Integr04_ZnSe AugerRecombination" "Integr05_CZTSe AugerRecombination"
    "Integr06_CZTSe AugerRecombination" "Integr07_CZTSe AugerRecombination" "Integr08_CZTSe AugerRecombination" "Integr09_CZTSe AugerRecombination" "IntegrSemiconductor RadiativeRecombination"
    "Integr03_CdS RadiativeRecombination" "Integr04_ZnSe RadiativeRecombination" "Integr05_CZTSe RadiativeRecombination" "Integr06_CZTSe RadiativeRecombination" "Integr07_CZTSe RadiativeRecombination"
    "Integr08_CZTSe RadiativeRecombination" "Integr09_CZTSe RadiativeRecombination" "IntegrSemiconductor eGapStatesRecombination" "Integr03_CdS eGapStatesRecombination" "Integr04_ZnSe eGapStatesRecombination"
    "Integr05_CZTSe eGapStatesRecombination" "Integr06_CZTSe eGapStatesRecombination" "Integr07_CZTSe eGapStatesRecombination" "Integr08_CZTSe eGapStatesRecombination" "Integr09_CZTSe eGapStatesRecombination"
    "IntegrSemiconductor PMIRecombination" "Integr03_CdS PMIRecombination" "Integr04_ZnSe PMIRecombination" "Integr05_CZTSe PMIRecombination" "Integr06_CZTSe PMIRecombination"
    "Integr07_CZTSe PMIRecombination" "Integr08_CZTSe PMIRecombination" "Integr09_CZTSe PMIRecombination" "IntegrSemiconductor srhRecombination" "Integr03_CdS srhRecombination"
    "Integr04_ZnSe srhRecombination" "Integr05_CZTSe srhRecombination" "Integr06_CZTSe srhRecombination" "Integr07_CZTSe srhRecombination" "Integr08_CZTSe srhRecombination"
    "Integr09_CZTSe srhRecombination" "IntegrSemiconductor TotalRecombination" "Integr03_CdS TotalRecombination" "Integr04_ZnSe TotalRecombination" "Integr05_CZTSe TotalRecombination"
    "Integr06_CZTSe TotalRecombination" "Integr07_CZTSe TotalRecombination" "Integr08_CZTSe TotalRecombination" "Integr09_CZTSe TotalRecombination" "Ave03_CdS eDensity"
    "Ave04_ZnSe eDensity" "Ave05_CZTSe eDensity" "Ave06_CZTSe eDensity" "Ave07_CZTSe eDensity" "Ave08_CZTSe eDensity"
    "Ave09_CZTSe eDensity" "Ave03_CdS EffectiveIntrinsicDensity" "Ave04_ZnSe EffectiveIntrinsicDensity" "Ave05_CZTSe EffectiveIntrinsicDensity" "Ave06_CZTSe EffectiveIntrinsicDensity"
    "Ave07_CZTSe EffectiveIntrinsicDensity" "Ave08_CZTSe EffectiveIntrinsicDensity" "Ave09_CZTSe EffectiveIntrinsicDensity" "Ave03_CdS hDensity" "Ave04_ZnSe hDensity"
    "Ave05_CZTSe hDensity" "Ave06_CZTSe hDensity" "Ave07_CZTSe hDensity" "Ave08_CZTSe hDensity" "Ave09_CZTSe hDensity"
    "Integr04_ZnSe/05_CZTSe SurfaceRecombination" "Integr05_CZTSe/11_Gas SurfaceRecombination" "Integr05_CZTSe/12_Gas SurfaceRecombination" "Integr05_CZTSe/13_Gas SurfaceRecombination" "Integr05_CZTSe/14_Gas SurfaceRecombination"
    "Integr05_CZTSe/06_CZTSe SurfaceRecombination" "Integr05_CZTSe/07_CZTSe SurfaceRecombination" "Integr05_CZTSe/08_CZTSe SurfaceRecombination" "Integr05_CZTSe/09_CZTSe SurfaceRecombination" "Integr06_CZTSe/11_Gas SurfaceRecombination"
    "Integr06_CZTSe/13_Gas SurfaceRecombination" "Integr06_CZTSe/07_CZTSe SurfaceRecombination" "Integr06_CZTSe/08_CZTSe SurfaceRecombination" "Integr07_CZTSe/11_Gas SurfaceRecombination" "Integr07_CZTSe/14_Gas SurfaceRecombination"
    "Integr08_CZTSe/12_Gas SurfaceRecombination" "Integr08_CZTSe/13_Gas SurfaceRecombination" "Integr09_CZTSe/12_Gas SurfaceRecombination" "Integr09_CZTSe/14_Gas SurfaceRecombination" "Integr09_CZTSe/07_CZTSe SurfaceRecombination"
    "Integr09_CZTSe/08_CZTSe SurfaceRecombination" ]
  functions = [
    Time
    OuterVoltage InnerVoltage QuasiFermiPotential DisplacementCurrent eCurrent
    hCurrent TotalCurrent Charge OuterVoltage InnerVoltage
    QuasiFermiPotential DisplacementCurrent eCurrent hCurrent TotalCurrent
    Charge ModelParameter OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AugerRecombination AugerRecombination AugerRecombination AugerRecombination
    AugerRecombination AugerRecombination AugerRecombination AugerRecombination RadiativeRecombination
    RadiativeRecombination RadiativeRecombination RadiativeRecombination RadiativeRecombination RadiativeRecombination
    RadiativeRecombination RadiativeRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination
    eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination
    PMIRecombination PMIRecombination PMIRecombination PMIRecombination PMIRecombination
    PMIRecombination PMIRecombination PMIRecombination srhRecombination srhRecombination
    srhRecombination srhRecombination srhRecombination srhRecombination srhRecombination
    srhRecombination TotalRecombination TotalRecombination TotalRecombination TotalRecombination
    TotalRecombination TotalRecombination TotalRecombination TotalRecombination eDensity
    eDensity eDensity eDensity eDensity eDensity
    eDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity
    EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity hDensity hDensity
    hDensity hDensity hDensity hDensity hDensity
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination ]
}

Data {
      0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   6.74508351211614E-13
     -1.11290562220062E-10  -1.10616053868850E-10  -4.94514111692200E-18   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   1.10616054599187E-10   0.00000000000000E+00   1.10616054599187E-10
      4.94514111692183E-18   3.00000000000000E-01   7.37427728342121E+08   0.00000000000000E+00   7.37427728342121E+08
      2.45809242780709E+09   4.53801678980402E+20   0.00000000000000E+00   4.53801678980402E+20   1.51267226326802E+21
      2.46512387399426E+07   0.00000000000000E+00   2.46512387399426E+07   8.21707957998151E+07   7.76077294286918E+03
      0.00000000000000E+00   7.76077294286918E+03   2.58692431428930E+04   7.07027365726653E+08   0.00000000000000E+00
      7.07027365726653E+08   2.35675788575544E+09   1.28212434798865E+06   0.00000000000000E+00   1.28212434798865E+06
      4.27374782662881E+06   1.48641291824129E+06   0.00000000000000E+00   1.48641291824129E+06   4.95470972747107E+06
      1.48641291824129E+06   0.00000000000000E+00   1.48641291824129E+06   4.95470972747105E+06   1.48641291824129E+06
      0.00000000000000E+00   1.48641291824129E+06   4.95470972747105E+06   2.45871326951989E+09   6.20841713636668E+05
      2.45809242780709E+09   3.10690295618945E+09   1.86250646903549E+07   3.08827789150030E+09   4.36578062754251E+08
      1.39679325350884E+07   4.22610130219194E+08   2.24337534830441E+07   8.91834316634724E+05   2.15419191664116E+07
      8.23597023105000E+07   1.88906510686212E+05   8.21707957998151E+07   2.60291803432011E+04   1.59937200305872E+02
      2.58692431428930E+04   2.35718948890336E+09   4.31603148692433E+05   2.35675788575544E+09   4.27378352644965E+06
      3.56998210119259E+01   4.27374782662881E+06   4.95475519988319E+06   4.54724122553986E+01   4.95470972747107E+06
      4.95475519988320E+06   4.54724122553984E+01   4.95470972747105E+06   4.95475519988318E+06   4.54724122553989E+01
      4.95470972747105E+06   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   3.46787462190373E+07   2.42525511285710E+07
      7.59210013303864E+03   1.03019118729621E+07   2.86190820555237E+04   2.93241402305625E+04   2.92854672710745E+04
      2.94624278159330E+04  -7.02746034053509E+08  -3.98687611373610E+05  -1.68672807474755E+02  -6.96723840131420E+08
     -1.25317768696333E+06  -1.45675229529553E+06  -1.45679331872460E+06  -1.45661433690775E+06   2.27782535205614E+16
      1.47571001061053E+13   3.06691870586005E+15   3.43429668810715E+09   3.51890378318089E+09   3.51426302223076E+09
      3.53549831579517E+09   3.24049831516144E-02   7.68680165220539E-05   3.94692015809295E+09   2.08659512970300E+09
      2.08659512970299E+09   2.08659512970299E+09   2.08659512970296E+09   1.21262755681571E+06   1.51842002682238E+03
      8.06301865097034E+14   1.76999539071592E+15   1.77005448171560E+15   1.77003762888510E+15   1.77005619607037E+15
      5.83091892629231E+04   1.41736041370208E+06   1.38483251437006E+06   1.38754132078703E+06   1.39325832134113E+06
      3.04882461529807E+05   3.15244210741129E+05   3.15879131296356E+05   3.17808267538678E+05   1.05193839626719E+05
      8.47670065162769E+04   1.75237333560072E+05   1.74367266011110E+05   1.04157433109311E+05   8.77986720011734E+04
      1.00085654401411E+05   9.93338990265660E+04   9.47808280732644E+04   1.00278461766502E+05   1.76987948313642E+05
      1.76887510203377E+05
      1.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   6.74546628999848E-13
     -1.11358309940856E-10  -1.10683763311857E-10  -4.94514178690105E-18   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   1.10683763942960E-10   0.00000000000000E+00   1.10683763942960E-10
      4.94514178690348E-18   3.00000000000000E-01   7.38048570056350E+08   6.20841713636668E+05   7.37427728342121E+08
      2.45809242780709E+09   4.54183735419928E+20   3.82056439161561E+17   4.53801678980402E+20   1.51267226326802E+21
      2.48401452506318E+07   1.88906510686212E+05   2.46512387399426E+07   8.21707957998151E+07   7.92071014317393E+03
      1.59937200305872E+02   7.76077294286918E+03   2.58692431428930E+04   7.07458968875438E+08   4.31603148692433E+05
      7.07027365726653E+08   2.35675788575544E+09   1.28216004780960E+06   3.56998210119259E+01   1.28212434798865E+06
      4.27374782662881E+06   1.48645839065352E+06   4.54724122553986E+01   1.48641291824129E+06   4.95470972747107E+06
      1.48645839065351E+06   4.54724122553984E+01   1.48641291824129E+06   4.95470972747105E+06   1.48645839065351E+06
      4.54724122553989E+01   1.48641291824129E+06   4.95470972747105E+06   2.45871326951989E+09   6.20841713636668E+05
      2.45809242780709E+09   3.10690295618945E+09   1.86250646903549E+07   3.08827789150030E+09   4.36578062754251E+08
      1.39679325350884E+07   4.22610130219194E+08   2.24337534830441E+07   8.91834316634724E+05   2.15419191664116E+07
      8.23597023105000E+07   1.88906510686212E+05   8.21707957998151E+07   2.60291803432011E+04   1.59937200305872E+02
      2.58692431428930E+04   2.35718948890336E+09   4.31603148692433E+05   2.35675788575544E+09   4.27378352644965E+06
      3.56998210119259E+01   4.27374782662881E+06   4.95475519988319E+06   4.54724122553986E+01   4.95470972747107E+06
      4.95475519988320E+06   4.54724122553984E+01   4.95470972747105E+06   4.95475519988318E+06   4.54724122553989E+01
      4.95470972747105E+06   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   3.48709905909249E+07   2.44379255202018E+07
      7.74844588134899E+03   1.03086172649970E+07   2.86211163816376E+04   2.93262078260764E+04   2.92875333635857E+04
      2.94645022712721E+04  -7.03174630869355E+08  -4.02219730429113E+05  -1.72264259421879E+02  -6.97148737463624E+08
     -1.25321132736897E+06  -1.45679567458285E+06  -1.45683669968273E+06  -1.45665770941902E+06   2.27782512314100E+16
      1.47570938534058E+13   3.06691912430961E+15   3.43454080756650E+09   3.51915189497434E+09   3.51451095366362E+09
      3.53574725076891E+09   3.24049831516144E-02   7.68680165220539E-05   3.94692015809295E+09   2.08659512970300E+09
      2.08659512970299E+09   2.08659512970299E+09   2.08659512970296E+09   1.22189627640263E+06   1.54968917649334E+03
      8.06301951168279E+14   1.76999538741077E+15   1.77005447842456E+15   1.77003762559096E+15   1.77005619278089E+15
      5.83605694166871E+04   1.41787701698941E+06   1.38534618013714E+06   1.38805539006865E+06   1.39377273152899E+06
      3.04907953438996E+05   3.15270176690803E+05   3.15905165521410E+05   3.17834381485598E+05   1.05201549009330E+05
      8.47731388867753E+04   1.75250028192274E+05   1.74379891425239E+05   1.04165008585655E+05   8.78049463504509E+04
      1.00092835616937E+05   9.93410444228795E+04   9.47876163452992E+04   1.00285651025021E+05   1.77000694878010E+05
      1.76900252079318E+05
}
