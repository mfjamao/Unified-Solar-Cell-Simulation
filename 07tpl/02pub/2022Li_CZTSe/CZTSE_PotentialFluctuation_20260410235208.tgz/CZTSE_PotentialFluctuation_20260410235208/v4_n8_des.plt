DF-ISE text

Info {
  version   = 1.0
  type      = xyplot
  datasets  = [
    "time"
    "c1 OuterVoltage" "c1 InnerVoltage" "c1 QuasiFermiPotential" "c1 DisplacementCurrent" "c1 eCurrent"
    "c1 hCurrent" "c1 TotalCurrent" "c1 Charge" "c2 OuterVoltage" "c2 InnerVoltage"
    "c2 QuasiFermiPotential" "c2 DisplacementCurrent" "c2 eCurrent" "c2 hCurrent" "c2 TotalCurrent"
    "c2 Charge" "Device=,File=CommandFile/Physics,DefaultRegionPhysics,ModelParameter=Optics/Excitation/Wavelength" "IntegrSemiconductor OpticalGeneration" "IntegrSemiconductor OpticalGenerationFromMonochromaticSource" "IntegrSemiconductor OpticalGenerationFromSpectrum"
    "IntegrSemiconductor OpticalGenerationFromSpectrumUnscaled" "AveSemiconductor OpticalGeneration" "AveSemiconductor OpticalGenerationFromMonochromaticSource" "AveSemiconductor OpticalGenerationFromSpectrum" "AveSemiconductor OpticalGenerationFromSpectrumUnscaled"
    "Integr03_CdS OpticalGeneration" "Integr03_CdS OpticalGenerationFromMonochromaticSource" "Integr03_CdS OpticalGenerationFromSpectrum" "Integr03_CdS OpticalGenerationFromSpectrumUnscaled" "Integr04_ZnSe OpticalGeneration"
    "Integr04_ZnSe OpticalGenerationFromMonochromaticSource" "Integr04_ZnSe OpticalGenerationFromSpectrum" "Integr04_ZnSe OpticalGenerationFromSpectrumUnscaled" "Integr05_CZTSe OpticalGeneration" "Integr05_CZTSe OpticalGenerationFromMonochromaticSource"
    "Integr05_CZTSe OpticalGenerationFromSpectrum" "Integr05_CZTSe OpticalGenerationFromSpectrumUnscaled" "Integr06_CZTSe OpticalGeneration" "Integr06_CZTSe OpticalGenerationFromMonochromaticSource" "Integr06_CZTSe OpticalGenerationFromSpectrum"
    "Integr06_CZTSe OpticalGenerationFromSpectrumUnscaled" "Integr07_CZTSe OpticalGeneration" "Integr07_CZTSe OpticalGenerationFromMonochromaticSource" "Integr07_CZTSe OpticalGenerationFromSpectrum" "Integr07_CZTSe OpticalGenerationFromSpectrumUnscaled"
    "Integr08_CZTSe OpticalGeneration" "Integr08_CZTSe OpticalGenerationFromMonochromaticSource" "Integr08_CZTSe OpticalGenerationFromSpectrum" "Integr08_CZTSe OpticalGenerationFromSpectrumUnscaled" "Integr09_CZTSe OpticalGeneration"
    "Integr09_CZTSe OpticalGenerationFromMonochromaticSource" "Integr09_CZTSe OpticalGenerationFromSpectrum" "Integr09_CZTSe OpticalGenerationFromSpectrumUnscaled" "IntegrSemiconductor AbsorbedPhotonDensity" "IntegrSemiconductor AbsorbedPhotonDensityFromMonochromaticSource"
    "IntegrSemiconductor AbsorbedPhotonDensityFromSpectrum" "Integr AbsorbedPhotonDensity" "Integr AbsorbedPhotonDensityFromMonochromaticSource" "Integr AbsorbedPhotonDensityFromSpectrum" "Integr01_AZO AbsorbedPhotonDensity"
    "Integr01_AZO AbsorbedPhotonDensityFromMonochromaticSource" "Integr01_AZO AbsorbedPhotonDensityFromSpectrum" "Integr02_IZO AbsorbedPhotonDensity" "Integr02_IZO AbsorbedPhotonDensityFromMonochromaticSource" "Integr02_IZO AbsorbedPhotonDensityFromSpectrum"
    "Integr03_CdS AbsorbedPhotonDensity" "Integr03_CdS AbsorbedPhotonDensityFromMonochromaticSource" "Integr03_CdS AbsorbedPhotonDensityFromSpectrum" "Integr04_ZnSe AbsorbedPhotonDensity" "Integr04_ZnSe AbsorbedPhotonDensityFromMonochromaticSource"
    "Integr04_ZnSe AbsorbedPhotonDensityFromSpectrum" "Integr05_CZTSe AbsorbedPhotonDensity" "Integr05_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr05_CZTSe AbsorbedPhotonDensityFromSpectrum" "Integr06_CZTSe AbsorbedPhotonDensity"
    "Integr06_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr06_CZTSe AbsorbedPhotonDensityFromSpectrum" "Integr07_CZTSe AbsorbedPhotonDensity" "Integr07_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr07_CZTSe AbsorbedPhotonDensityFromSpectrum"
    "Integr08_CZTSe AbsorbedPhotonDensity" "Integr08_CZTSe AbsorbedPhotonDensityFromMonochromaticSource" "Integr08_CZTSe AbsorbedPhotonDensityFromSpectrum" "Integr09_CZTSe AbsorbedPhotonDensity" "Integr09_CZTSe AbsorbedPhotonDensityFromMonochromaticSource"
    "Integr09_CZTSe AbsorbedPhotonDensityFromSpectrum" "IntegrSemiconductor AugerRecombination" "Integr03_CdS AugerRecombination" "Integr04_ZnSe AugerRecombination" "Integr05_CZTSe AugerRecombination"
    "Integr06_CZTSe AugerRecombination" "Integr07_CZTSe AugerRecombination" "Integr08_CZTSe AugerRecombination" "Integr09_CZTSe AugerRecombination" "IntegrSemiconductor RadiativeRecombination"
    "Integr03_CdS RadiativeRecombination" "Integr04_ZnSe RadiativeRecombination" "Integr05_CZTSe RadiativeRecombination" "Integr06_CZTSe RadiativeRecombination" "Integr07_CZTSe RadiativeRecombination"
    "Integr08_CZTSe RadiativeRecombination" "Integr09_CZTSe RadiativeRecombination" "IntegrSemiconductor eGapStatesRecombination" "Integr03_CdS eGapStatesRecombination" "Integr04_ZnSe eGapStatesRecombination"
    "Integr05_CZTSe eGapStatesRecombination" "Integr06_CZTSe eGapStatesRecombination" "Integr07_CZTSe eGapStatesRecombination" "Integr08_CZTSe eGapStatesRecombination" "Integr09_CZTSe eGapStatesRecombination"
    "IntegrSemiconductor PMIRecombination" "Integr03_CdS PMIRecombination" "Integr04_ZnSe PMIRecombination" "Integr05_CZTSe PMIRecombination" "Integr06_CZTSe PMIRecombination"
    "Integr07_CZTSe PMIRecombination" "Integr08_CZTSe PMIRecombination" "Integr09_CZTSe PMIRecombination" "IntegrSemiconductor srhRecombination" "Integr03_CdS srhRecombination"
    "Integr04_ZnSe srhRecombination" "Integr05_CZTSe srhRecombination" "Integr06_CZTSe srhRecombination" "Integr07_CZTSe srhRecombination" "Integr08_CZTSe srhRecombination"
    "Integr09_CZTSe srhRecombination" "IntegrSemiconductor TotalRecombination" "Integr03_CdS TotalRecombination" "Integr04_ZnSe TotalRecombination" "Integr05_CZTSe TotalRecombination"
    "Integr06_CZTSe TotalRecombination" "Integr07_CZTSe TotalRecombination" "Integr08_CZTSe TotalRecombination" "Integr09_CZTSe TotalRecombination" "Ave03_CdS eDensity"
    "Ave04_ZnSe eDensity" "Ave05_CZTSe eDensity" "Ave06_CZTSe eDensity" "Ave07_CZTSe eDensity" "Ave08_CZTSe eDensity"
    "Ave09_CZTSe eDensity" "Ave03_CdS EffectiveIntrinsicDensity" "Ave04_ZnSe EffectiveIntrinsicDensity" "Ave05_CZTSe EffectiveIntrinsicDensity" "Ave06_CZTSe EffectiveIntrinsicDensity"
    "Ave07_CZTSe EffectiveIntrinsicDensity" "Ave08_CZTSe EffectiveIntrinsicDensity" "Ave09_CZTSe EffectiveIntrinsicDensity" "Ave03_CdS hDensity" "Ave04_ZnSe hDensity"
    "Ave05_CZTSe hDensity" "Ave06_CZTSe hDensity" "Ave07_CZTSe hDensity" "Ave08_CZTSe hDensity" "Ave09_CZTSe hDensity"
    "Integr04_ZnSe/05_CZTSe SurfaceRecombination" "Integr05_CZTSe/11_Gas SurfaceRecombination" "Integr05_CZTSe/12_Gas SurfaceRecombination" "Integr05_CZTSe/13_Gas SurfaceRecombination" "Integr05_CZTSe/14_Gas SurfaceRecombination"
    "Integr05_CZTSe/06_CZTSe SurfaceRecombination" "Integr05_CZTSe/07_CZTSe SurfaceRecombination" "Integr05_CZTSe/08_CZTSe SurfaceRecombination" "Integr05_CZTSe/09_CZTSe SurfaceRecombination" "Integr06_CZTSe/11_Gas SurfaceRecombination"
    "Integr06_CZTSe/13_Gas SurfaceRecombination" "Integr06_CZTSe/07_CZTSe SurfaceRecombination" "Integr06_CZTSe/08_CZTSe SurfaceRecombination" "Integr07_CZTSe/11_Gas SurfaceRecombination" "Integr07_CZTSe/14_Gas SurfaceRecombination"
    "Integr08_CZTSe/12_Gas SurfaceRecombination" "Integr08_CZTSe/13_Gas SurfaceRecombination" "Integr09_CZTSe/12_Gas SurfaceRecombination" "Integr09_CZTSe/14_Gas SurfaceRecombination" "Integr09_CZTSe/07_CZTSe SurfaceRecombination"
    "Integr09_CZTSe/08_CZTSe SurfaceRecombination" ]
  functions = [
    Time
    OuterVoltage InnerVoltage QuasiFermiPotential DisplacementCurrent eCurrent
    hCurrent TotalCurrent Charge OuterVoltage InnerVoltage
    QuasiFermiPotential DisplacementCurrent eCurrent hCurrent TotalCurrent
    Charge ModelParameter OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AugerRecombination AugerRecombination AugerRecombination AugerRecombination
    AugerRecombination AugerRecombination AugerRecombination AugerRecombination RadiativeRecombination
    RadiativeRecombination RadiativeRecombination RadiativeRecombination RadiativeRecombination RadiativeRecombination
    RadiativeRecombination RadiativeRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination
    eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination
    PMIRecombination PMIRecombination PMIRecombination PMIRecombination PMIRecombination
    PMIRecombination PMIRecombination PMIRecombination srhRecombination srhRecombination
    srhRecombination srhRecombination srhRecombination srhRecombination srhRecombination
    srhRecombination TotalRecombination TotalRecombination TotalRecombination TotalRecombination
    TotalRecombination TotalRecombination TotalRecombination TotalRecombination eDensity
    eDensity eDensity eDensity eDensity eDensity
    eDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity
    EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity hDensity hDensity
    hDensity hDensity hDensity hDensity hDensity
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination ]
}

Data {
      0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   3.70481648494469E-13
     -1.09280778814730E-10  -1.08910297166236E-10  -4.90726848441240E-18   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   1.08910297202402E-10   0.00000000000000E+00   1.08910297202402E-10
      4.90726848441138E-18   3.00000000000000E-01   7.37427728342121E+08   0.00000000000000E+00   7.37427728342121E+08
      2.45809242780709E+09   4.53801678980402E+20   0.00000000000000E+00   4.53801678980402E+20   1.51267226326802E+21
      2.46512387399426E+07   0.00000000000000E+00   2.46512387399426E+07   8.21707957998151E+07   7.76077294286918E+03
      0.00000000000000E+00   7.76077294286918E+03   2.58692431428930E+04   7.07027365726653E+08   0.00000000000000E+00
      7.07027365726653E+08   2.35675788575544E+09   1.28212434798865E+06   0.00000000000000E+00   1.28212434798865E+06
      4.27374782662881E+06   1.48641291824129E+06   0.00000000000000E+00   1.48641291824129E+06   4.95470972747107E+06
      1.48641291824129E+06   0.00000000000000E+00   1.48641291824129E+06   4.95470972747105E+06   1.48641291824129E+06
      0.00000000000000E+00   1.48641291824129E+06   4.95470972747105E+06   2.45871326951989E+09   6.20841713636668E+05
      2.45809242780709E+09   3.10690295618945E+09   1.86250646903549E+07   3.08827789150030E+09   4.36578062754251E+08
      1.39679325350884E+07   4.22610130219194E+08   2.24337534830441E+07   8.91834316634724E+05   2.15419191664116E+07
      8.23597023105000E+07   1.88906510686212E+05   8.21707957998151E+07   2.60291803432011E+04   1.59937200305872E+02
      2.58692431428930E+04   2.35718948890336E+09   4.31603148692433E+05   2.35675788575544E+09   4.27378352644965E+06
      3.56998210119259E+01   4.27374782662881E+06   4.95475519988319E+06   4.54724122553986E+01   4.95470972747107E+06
      4.95475519988320E+06   4.54724122553984E+01   4.95470972747105E+06   4.95475519988318E+06   4.54724122553989E+01
      4.95470972747105E+06   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   4.45240073927055E+07   2.42525510990398E+07
      7.59209996309845E+03   2.00541434217460E+07   5.16748804945221E+04   5.27555601125241E+04   5.24816993910137E+04
      5.28086319580930E+04  -6.92900068472860E+08  -3.98687640904189E+05  -1.68672977415031E+02  -6.86971364231447E+08
     -1.23000720827085E+06  -1.43320474078668E+06  -1.43348279464277E+06  -1.43315318383335E+06   2.27828010401060E+16
      1.47733607967662E+13   3.07735418357887E+15   6.20101033925462E+09   6.33069235321947E+09   6.29782895472239E+09
      6.33706099959499E+09   3.24049831516144E-02   7.68680165220539E-05   4.84151890914199E+09   2.98311110197235E+09
      2.98311110197234E+09   2.98311110197235E+09   2.98311110197236E+09   1.21262755533886E+06   1.51841999283407E+03
      7.49793668727083E+14   2.65433770503440E+15   2.65469201228723E+15   2.65458978831671E+15   2.65470665871496E+15
      1.16681900148063E+04   1.92122685291834E+06   1.89640389664725E+06   1.89731377397413E+06   1.90217121968560E+06
      2.41648120370329E+05   2.49704620012722E+05   2.49318031818021E+05   2.50777596037795E+05   1.67311163092693E+05
      1.41007785463039E+05   2.94168022402384E+05   2.93028218738473E+05   1.64307306942032E+05   1.45279229599031E+05
      1.66617733541445E+05   1.65672924270853E+05   1.59704804929715E+05   1.67280276447658E+05   2.96758313563083E+05
      2.96214114603724E+05
      1.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   3.70501640381484E-13
     -1.09347218094307E-10  -1.08976716453926E-10  -4.90726893381417E-18   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   1.08976716618965E-10   0.00000000000000E+00   1.08976716618965E-10
      4.90726893381303E-18   3.00000000000000E-01   7.38048570056350E+08   6.20841713636668E+05   7.37427728342121E+08
      2.45809242780709E+09   4.54183735419928E+20   3.82056439161561E+17   4.53801678980402E+20   1.51267226326802E+21
      2.48401452506318E+07   1.88906510686212E+05   2.46512387399426E+07   8.21707957998151E+07   7.92071014317393E+03
      1.59937200305872E+02   7.76077294286918E+03   2.58692431428930E+04   7.07458968875438E+08   4.31603148692433E+05
      7.07027365726653E+08   2.35675788575544E+09   1.28216004780960E+06   3.56998210119259E+01   1.28212434798865E+06
      4.27374782662881E+06   1.48645839065352E+06   4.54724122553986E+01   1.48641291824129E+06   4.95470972747107E+06
      1.48645839065351E+06   4.54724122553984E+01   1.48641291824129E+06   4.95470972747105E+06   1.48645839065351E+06
      4.54724122553989E+01   1.48641291824129E+06   4.95470972747105E+06   2.45871326951989E+09   6.20841713636668E+05
      2.45809242780709E+09   3.10690295618945E+09   1.86250646903549E+07   3.08827789150030E+09   4.36578062754251E+08
      1.39679325350884E+07   4.22610130219194E+08   2.24337534830441E+07   8.91834316634724E+05   2.15419191664116E+07
      8.23597023105000E+07   1.88906510686212E+05   8.21707957998151E+07   2.60291803432011E+04   1.59937200305872E+02
      2.58692431428930E+04   2.35718948890336E+09   4.31603148692433E+05   2.35675788575544E+09   4.27378352644965E+06
      3.56998210119259E+01   4.27374782662881E+06   4.95475519988319E+06   4.54724122553986E+01   4.95470972747107E+06
      4.95475519988320E+06   4.54724122553984E+01   4.95470972747105E+06   4.95475519988318E+06   4.54724122553989E+01
      4.95470972747105E+06   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   4.47231674474537E+07   2.44379254904240E+07
      7.74844570819744E+03   2.00677591723571E+07   5.16782392491203E+04   5.27589689850523E+04   5.24850915137503E+04
      5.28120392183534E+04  -6.93321749370966E+08  -4.02219760206657E+05  -1.72264432573407E+02  -6.87389350990383E+08
     -1.23003951920716E+06  -1.43324677367413E+06  -1.43352484455634E+06  -1.43319521849608E+06   2.27827988211567E+16
      1.47733547527053E+13   3.07735465357112E+15   6.20141339123843E+09   6.33110141938200E+09   6.29823601090173E+09
      6.33746987228522E+09   3.24049831516144E-02   7.68680165220539E-05   4.84151890914199E+09   2.98311110197235E+09
      2.98311110197234E+09   2.98311110197235E+09   2.98311110197236E+09   1.22189627491339E+06   1.54968914186276E+03
      7.49793862918830E+14   2.65433761323363E+15   2.65469192048910E+15   2.65458969651593E+15   2.65470656692351E+15
      1.16784699806058E+04   1.92205693633210E+06   1.89723194799183E+06   1.89814193248310E+06   1.90299973251182E+06
      2.41666780066244E+05   2.49723639391307E+05   2.49337039919117E+05   2.50796660657294E+05   1.67322237558301E+05
      1.41017049867444E+05   2.94187312654020E+05   2.93047429786236E+05   1.64318131192356E+05   1.45288690131892E+05
      1.66628640878809E+05   1.65683793830367E+05   1.59715257592085E+05   1.67291219717565E+05   2.96777690525908E+05
      2.96233458400431E+05
}
