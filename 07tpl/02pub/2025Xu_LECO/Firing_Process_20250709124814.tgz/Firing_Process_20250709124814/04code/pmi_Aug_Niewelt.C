// This PMI implemented the Auger parameterization by 2022Niewelt using
// the standard C++ physical model interface

// Created by Dr. Fa-Jun MA (mfjamao@yahoo.com)

#include <stdlib.h>
#include <math.h>
#include "PMIModels.h"

// Derive Auger_Recombination from PMI_Recombination
class Auger_Recombination : public PMI_Recombination {
    double Ceeh;
    double Cehh;
    double fPR;
    public:
        Auger_Recombination(const PMI_Environment& env);
        ~Auger_Recombination();

        void Compute_r(const double t,       // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& r);             // recombination rate

        // with respect to lattice temperature
        void Compute_drdt(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdt);          // derivative of recombination rate

        // with respect to electron density
        void Compute_drdn(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdn);          // derivative of recombination rate

        // with respect to hole density
        void Compute_drdp(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdp);          // derivative of recombination rate

        // with respect to effective intrinsic density
        void Compute_drdnie(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdnie);        // derivative of recombination rate

        // with respect to absolute value of electric field
        void Compute_drdf(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdf);          // derivative of recombination rate
};

Auger_Recombination::Auger_Recombination(const PMI_Environment& env) :
    PMI_Recombination(env) {
    Ceeh = InitParameter("Ceeh", 3.41e-31);
    // std::cout << "PMI_Niewelt: Ceeh = " << Ceeh << " cm^6/s\n";
    Cehh = InitParameter("Cehh", 1.17e-31);
    // std::cout << "PMI_Niewelt: Cehh = " << Cehh << " cm^6/s\n";
    fPR = InitParameter("fPR", 0);
    // std::cout << "PMI_Niewelt: fPR = " << fPR << "\n";
}

Auger_Recombination::~Auger_Recombination() { }

void Auger_Recombination::Compute_r(const double t, const double n,
    const double p, const double nie, const double f, double& r) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    r = -1e15 * f * f;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 2022Niewelt (10.1016/j.solmat.2021.111467), Eqs. (8), (10) and Table 2
    double geeh = 1. + (4.38 - 1.) / (1. + (n + p) * (n + p) / 4e17 /4e17);
    double gehh = 1. + (4.88 - 1.) / (1. + (n + p) * (n + p) / 4e17 /4e17);
    r = (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad)
        * (n * p - nie * nie);
    if (r < 0.0) {
        r = 0.0;
    }
    #endif
}

void Auger_Recombination::Compute_drdt(const double t, const double n,
    const double p, const double nie, const double f, double& drdt) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdt = 0.0;
    #else

    // Auger recombination
    drdt = 0.0;
    #endif
}

void Auger_Recombination::Compute_drdn(const double t, const double n,
    const double p, const double nie, const double f, double& drdn) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdn = 0.0;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 2022Niewelt (10.1016/j.solmat.2021.111467), Eqs. (8), (10) and Table 2
    double geeh = 1. + (4.38 - 1.) / (1. + (n + p) * (n + p) / 4e17 /4e17);
    double gehh = 1. + (4.88 - 1.) / (1. + (n + p) * (n + p) / 4e17 /4e17);
    double r = (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad)
        * (n * p - nie * nie);
    if (r < 0.0) {
        drdn = 0.0;
    } else {
        drdn = Ceeh * geeh * (n * p - nie * nie)
            + (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad) * p;
    }
    #endif
}

void Auger_Recombination::Compute_drdp(const double t, const double n,
    const double p, const double nie, const double f, double& drdp) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdp = 0.0;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 2022Niewelt (10.1016/j.solmat.2021.111467), Eqs. (8), (10) and Table 2
    double geeh = 1. + (4.38 - 1.) / (1. + (n + p) * (n + p) / 4e17 /4e17);
    double gehh = 1. + (4.88 - 1.) / (1. + (n + p) * (n + p) / 4e17 /4e17);
    double r = (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad)
        * (n * p - nie * nie);
    if (r < 0.0) {
        drdp = 0.0;
    } else {
        drdp = Cehh * gehh * (n * p - nie * nie)
            + (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad) * n;
    }
    #endif
}

void Auger_Recombination::Compute_drdnie(const double t, const double n,
    const double p, const double nie, const double f, double& drdnie) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdnie = 0.0;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 2022Niewelt (10.1016/j.solmat.2021.111467), Eqs. (8), (10) and Table 2
    double geeh = 1. + (4.38 - 1.) / (1. + (n + p) * (n + p) / 4e17 /4e17);
    double gehh = 1. + (4.88 - 1.) / (1. + (n + p) * (n + p) / 4e17 /4e17);
    double r = (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad)
        * (n * p - nie * nie);
    if (r < 0.0) {
        drdnie = 0.0;
    } else {
        drdnie = (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad)
            * (- 2.0 * nie);
    }
    #endif
}

void Auger_Recombination::Compute_drdf(const double t, const double n,
    const double p, const double nie, const double f, double& drdf) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdf = -1e15 * 2.0 * f;
    #else

    // Auger recombination
    drdf = 0.0;
    #endif
}

extern "C" {
    PMI_Recombination* new_PMI_Recombination(const PMI_Environment& env) {
        return new Auger_Recombination(env);
    }

    int PMI_Recombination_ElectricField() {
        #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

        // test case for dependence on electric field
        return 1;
        #else

        // Auger recombination
        // model does not depend on electric field
        return 0;
        #endif
    }
}
