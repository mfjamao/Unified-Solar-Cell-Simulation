// This PMI implemented the Auger parameterization by 2012Richter using
// the standard C++ physical model interface

// Created by Dr. Fa-Jun MA (mfjamao@yahoo.com)

#include <stdlib.h>
#include <math.h>
#include "PMIModels.h"

// Derive Auger_Recombination from PMI_Recombination
class Auger_Recombination : public PMI_Recombination {
    double Ceeh;
    double Cehh;
    double CDn;
    double fPR;
    public:
        Auger_Recombination(const PMI_Environment& env);
        ~Auger_Recombination();

        void Compute_r(const double t,       // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& r);             // recombination rate

        // with respect to lattice temperature
        void Compute_drdt(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdt);          // derivative of recombination rate

        // with respect to electron density
        void Compute_drdn(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdn);          // derivative of recombination rate

        // with respect to hole density
        void Compute_drdp(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdp);          // derivative of recombination rate

        // with respect to effective intrinsic density
        void Compute_drdnie(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdnie);        // derivative of recombination rate

        // with respect to absolute value of electric field
        void Compute_drdf(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdf);          // derivative of recombination rate
};

Auger_Recombination::Auger_Recombination(const PMI_Environment& env) :
    PMI_Recombination(env) {
    // Ceeh = InitParameter("Ceeh", 2.5e-31);
    std::cout << "PMI_Richter: Ceeh = " << Ceeh << " cm^6/s\n";
    // Cehh = InitParameter("Cehh", 8.5e-32);
    std::cout << "PMI_Richter: Cehh = " << Cehh << " cm^6/s\n";
    CDn = InitParameter("CDn", 3e-29);
    // std::cout << "PMI_Richter: CDn = " << CDn << " cm^6/s\n";
    fPR = InitParameter("fPR", 0);
    // std::cout << "PMI_Richter: fPR = " << fPR << "\n";
}

Auger_Recombination::~Auger_Recombination() { }

void Auger_Recombination::Compute_r(const double t, const double n,
    const double p, const double nie, const double f, double& r) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    r = -1e15 * f * f;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 2012Richter (10.1103/PhysRevB.86.165202), Eqs. (18) - (19)
    const double NA = ReadDoping(PMI_Acceptor);
    const double ND = ReadDoping(PMI_Donor);
    const double pi = 2. * asin(1.);
    const double q = 1.602176634e-19;
    const double k = 1.380649e-23;          // J/K
    double Eg, ni, p0, n0, Dn;

    // 2002Passler, Eq. (23), Table I (2-415K)
    Eg = 1.17 - 3.23e-4 * 446. * ((1. - 3 * 0.51 * 0.51)
        / (exp(446. / t) - 1.) + 1.5 * 0.51 * 0.51
        * (pow(1. + pi * pi / 3. / (1. + 0.51 * 0.51) * pow(2 * t / 446., 2)
        + (3. * 0.51 * 0.51 -1.) / 4. * pow(2 * t / 446., 3)
        + 8. / 3. * pow(2 * t / 446., 4) + pow(2 * t / 446., 6), 1./6.) - 1.));

    // 2014Couderc, Eq. (15)
    ni = 1.541e15 * pow(t, 1.712) * exp(-q * Eg / 2 / k / t);

    // 2007Sze, Eqs. (42), (45)
    if (ND < NA) { // Electrons are minority carriers
        p0 = 0.5 * (NA - ND + sqrt(pow(NA - ND, 2) + 4. * ni * ni));
        n0 = ni * ni / p0;
        Dn = n < p ? n - n0 : p;
    } else { // Holes are minority carriers
        n0 = 0.5 * (ND - NA + sqrt(pow(ND - NA, 2) + 4. * ni * ni));
        p0 = ni * ni / n0;
        Dn = p < n ? p - p0 : n;
    }

    // Supress negative excess carrier density
    if (Dn < 0.0) Dn = 1e-30;

    double geeh = 1. + 13. * (1. - tanh(pow(n0 / 3.3e17, 0.66)));
    double gehh = 1. + 7.5 * (1. - tanh(pow(p0 / 7e17, 0.63)));
    r = (Ceeh * geeh * n0 + Cehh * gehh * p0 + CDn * pow(Dn, 0.92)
        + (1. - fPR) * Brad) * (n * p - nie * nie);
    if (r < 0.0) {
        r = 0.0;
    }
    #endif
}

void Auger_Recombination::Compute_drdt(const double t, const double n,
    const double p, const double nie, const double f, double& drdt) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdt = 0.0;
    #else

    // Auger recombination
    drdt = 0.0;
    #endif
}

void Auger_Recombination::Compute_drdn(const double t, const double n,
    const double p, const double nie, const double f, double& drdn) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdn = 0.0;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 2012Richter (10.1103/PhysRevB.86.165202), Eqs. (18) - (19)
    const double NA = ReadDoping(PMI_Acceptor);
    const double ND = ReadDoping(PMI_Donor);
    const double pi = 2. * asin(1.);
    const double q = 1.602176634e-19;
    const double k = 1.380649e-23;          // J/K
    double Eg, ni, p0, n0, Dn;

    // 2002Passler, Eq. (23), Table I (2-415K)
    Eg = 1.17 - 3.23e-4 * 446. * ((1. - 3 * 0.51 * 0.51)
        / (exp(446. / t) - 1.) + 1.5 * 0.51 * 0.51
        * (pow(1. + pi * pi / 3. / (1. + 0.51 * 0.51) * pow(2 * t / 446., 2)
        + (3. * 0.51 * 0.51 -1.) / 4. * pow(2 * t / 446., 3)
        + 8. / 3. * pow(2 * t / 446., 4) + pow(2 * t / 446., 6), 1./6.) - 1.));

    // 2014Couderc, Eq. (15)
    ni = 1.541e15 * pow(t, 1.712) * exp(-q * Eg / 2 / k / t);

    // 2007Sze, Eqs. (42), (45)
    if (ND < NA) { // Electrons are minority carriers
        p0 = 0.5 * (NA - ND + sqrt(pow(NA - ND, 2) + 4. * ni * ni));
        n0 = ni * ni / p0;
        Dn = n < p ? n - n0 : p;
    } else { // Holes are minority carriers
        n0 = 0.5 * (ND - NA + sqrt(pow(ND - NA, 2) + 4. * ni * ni));
        p0 = ni * ni / n0;
        Dn = p < n ? p - p0 : n;
    }

    // Supress negative excess carrier density
    if (Dn < 0.0) Dn = 1e-30;

    double geeh = 1. + 13. * (1. - tanh(pow(n0 / 3.3e17, 0.66)));
    double gehh = 1. + 7.5 * (1. - tanh(pow(p0 / 7e17, 0.63)));
    double r = (Ceeh * geeh * n0 + Cehh * gehh * p0 + CDn * pow(Dn, 0.92)
        + (1. - fPR) * Brad) * (n * p - nie * nie);
    if (r < 0.0) {
        drdn = 0.0;
    } else {
        drdn = (Ceeh * geeh * n0 + Cehh * gehh * p0 + CDn * pow(Dn, 0.92)
            + (1. - fPR) * Brad) * p;
    }
    #endif
}

void Auger_Recombination::Compute_drdp(const double t, const double n,
    const double p, const double nie, const double f, double& drdp) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdp = 0.0;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 2012Richter (10.1103/PhysRevB.86.165202), Eqs. (18) - (19)
    const double NA = ReadDoping(PMI_Acceptor);
    const double ND = ReadDoping(PMI_Donor);
    const double pi = 2. * asin(1.);
    const double q = 1.602176634e-19;
    const double k = 1.380649e-23;          // J/K
    double Eg, ni, p0, n0, Dn;

    // 2002Passler, Eq. (23), Table I (2-415K)
    Eg = 1.17 - 3.23e-4 * 446. * ((1. - 3 * 0.51 * 0.51)
        / (exp(446. / t) - 1.) + 1.5 * 0.51 * 0.51
        * (pow(1. + pi * pi / 3. / (1. + 0.51 * 0.51) * pow(2 * t / 446., 2)
        + (3. * 0.51 * 0.51 -1.) / 4. * pow(2 * t / 446., 3)
        + 8. / 3. * pow(2 * t / 446., 4) + pow(2 * t / 446., 6), 1./6.) - 1.));

    // 2014Couderc, Eq. (15)
    ni = 1.541e15 * pow(t, 1.712) * exp(-q * Eg / 2 / k / t);

    // 2007Sze, Eqs. (42), (45)
    if (ND < NA) { // Electrons are minority carriers
        p0 = 0.5 * (NA - ND + sqrt(pow(NA - ND, 2) + 4. * ni * ni));
        n0 = ni * ni / p0;
        Dn = n < p ? n - n0 : p;
    } else { // Holes are minority carriers
        n0 = 0.5 * (ND - NA + sqrt(pow(ND - NA, 2) + 4. * ni * ni));
        p0 = ni * ni / n0;
        Dn = p < n ? p - p0 : n;
    }

    // Supress negative excess carrier density
    if (Dn < 0.0) Dn = 1e-30;

    double geeh = 1. + 13. * (1. - tanh(pow(n0 / 3.3e17, 0.66)));
    double gehh = 1. + 7.5 * (1. - tanh(pow(p0 / 7e17, 0.63)));
    double r = (Ceeh * geeh * n0 + Cehh * gehh * p0 + CDn * pow(Dn, 0.92)
        + (1. - fPR) * Brad) * (n * p - nie * nie);
    if (r < 0.0) {
        drdp = 0.0;
    } else {
        drdp = (Ceeh * geeh * n0 + Cehh * gehh * p0 + CDn * pow(Dn, 0.92)
            + (1. - fPR) * Brad) * n;
    }
    #endif
}

void Auger_Recombination::Compute_drdnie(const double t, const double n,
    const double p, const double nie, const double f, double& drdnie) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdnie = 0.0;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 2012Richter (10.1103/PhysRevB.86.165202), Eqs. (18) - (19)
    const double NA = ReadDoping(PMI_Acceptor);
    const double ND = ReadDoping(PMI_Donor);
    const double pi = 2. * asin(1.);
    const double q = 1.602176634e-19;
    const double k = 1.380649e-23;          // J/K
    double Eg, ni, p0, n0, Dn;

    // 2002Passler, Eq. (23), Table I (2-415K)
    Eg = 1.17 - 3.23e-4 * 446. * ((1. - 3 * 0.51 * 0.51)
        / (exp(446. / t) - 1.) + 1.5 * 0.51 * 0.51
        * (pow(1. + pi * pi / 3. / (1. + 0.51 * 0.51) * pow(2 * t / 446., 2)
        + (3. * 0.51 * 0.51 -1.) / 4. * pow(2 * t / 446., 3)
        + 8. / 3. * pow(2 * t / 446., 4) + pow(2 * t / 446., 6), 1./6.) - 1.));

    // 2014Couderc, Eq. (15)
    ni = 1.541e15 * pow(t, 1.712) * exp(-q * Eg / 2 / k / t);

    // 2007Sze, Eqs. (42), (45)
    if (ND < NA) { // Electrons are minority carriers
        p0 = 0.5 * (NA - ND + sqrt(pow(NA - ND, 2) + 4. * ni * ni));
        n0 = ni * ni / p0;
        Dn = n < p ? n - n0 : p;
    } else { // Holes are minority carriers
        n0 = 0.5 * (ND - NA + sqrt(pow(ND - NA, 2) + 4. * ni * ni));
        p0 = ni * ni / n0;
        Dn = p < n ? p - p0 : n;
    }

    // Supress negative excess carrier density
    if (Dn < 0.0) Dn = 1e-30;

    double geeh = 1. + 13. * (1. - tanh(pow(n0 / 3.3e17, 0.66)));
    double gehh = 1. + 7.5 * (1. - tanh(pow(p0 / 7e17, 0.63)));
    double r = (Ceeh * geeh * n0 + Cehh * gehh * p0 + CDn * pow(Dn, 0.92)
        + (1. - fPR) * Brad) * (n * p - nie * nie);
    if (r < 0.0) {
        drdnie = 0.0;
    } else {
        drdnie = (Ceeh * geeh * n0 + Cehh * gehh * p0 + CDn * pow(Dn, 0.92)
            + (1. - fPR) * Brad) * (- 2.0 * nie);
    }
    #endif
}

void Auger_Recombination::Compute_drdf(const double t, const double n,
    const double p, const double nie, const double f, double& drdf) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdf = -1e15 * 2.0 * f;
    #else

    // Auger recombination
    drdf = 0.0;
    #endif
}

extern "C" {
    PMI_Recombination* new_PMI_Recombination(const PMI_Environment& env) {
        return new Auger_Recombination(env);
    }

    int PMI_Recombination_ElectricField() {
        #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

        // test case for dependence on electric field
        return 1;
        #else

        // Auger recombination
        // model does not depend on electric field
        return 0;
        #endif
    }
}
