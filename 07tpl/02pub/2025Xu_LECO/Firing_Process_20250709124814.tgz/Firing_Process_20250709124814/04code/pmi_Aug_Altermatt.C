// This PMI implemented the Auger parameterization by 1997Altermatt using
// the standard C++ physical model interface

// Created by Dr. Fa-Jun MA (mfjamao@yahoo.com)

#include <stdlib.h>
#include <math.h>
#include "PMIModels.h"

// Derive Auger_Recombination from PMI_Recombination
class Auger_Recombination : public PMI_Recombination {
    double Ceeh;
    double fPR;
    public:
        Auger_Recombination(const PMI_Environment& env);
        ~Auger_Recombination();

        void Compute_r(const double t,       // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& r);             // recombination rate

        // with respect to lattice temperature
        void Compute_drdt(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdt);          // derivative of recombination rate

        // with respect to electron density
        void Compute_drdn(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdn);          // derivative of recombination rate

        // with respect to hole density
        void Compute_drdp(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdp);          // derivative of recombination rate

        // with respect to effective intrinsic density
        void Compute_drdnie(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdnie);        // derivative of recombination rate

        // with respect to absolute value of electric field
        void Compute_drdf(const double t,        // lattice temperature
        const double n,         // electron density
        const double p,         // hole density
        const double nie,       // effective intrinsic density
        const double f,         // absolute value of electric field
        double& drdf);          // derivative of recombination rate
};

Auger_Recombination::Auger_Recombination(const PMI_Environment& env) :
    PMI_Recombination(env) {
    Ceeh = InitParameter("Ceeh", 2.8e-31);
    // std::cout << "PMI_Altermatt: Ceeh = " << Ceeh << " cm^6/s\n";
    fPR = InitParameter("fPR", 0);
    // std::cout << "PMI_Altermatt: fPR = " << fPR << "\n";
}

Auger_Recombination::~Auger_Recombination() { }

void Auger_Recombination::Compute_r(const double t, const double n,
    const double p, const double nie, const double f, double& r) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    r = -1e15 * f * f;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 1997Altermatt (10.1063/1.366360), Eqs. (5) - (6)
    double geeh = 1. + (235548. * pow(t, -1.5013) - 1.)
        * (1. - tanh(pow(n / 5e16, 0.34)));
    double gehh = 1. + (564812. * pow(t, -1.6546) - 1.)
        * (1. - tanh(pow(p / 5e16, 0.29)));
    double Cehh = 7.91e-32 - 4.13e-35 * t + 3.59e-37 * t * t;
    r = (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad)
        * (n * p - nie * nie);
    if (r < 0.0) {
        r = 0.0;
    }
    #endif
}

void Auger_Recombination::Compute_drdt(const double t, const double n,
    const double p, const double nie, const double f, double& drdt) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdt = 0.0;
    #else

    // Auger recombination
    drdt = 0.0;
    #endif
}

void Auger_Recombination::Compute_drdn(const double t, const double n,
    const double p, const double nie, const double f, double& drdn) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdn = 0.0;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 1997Altermatt (10.1063/1.366360), Eqs. (5) - (6)
    double geeh = 1. + (235548. * pow(t, -1.5013) - 1.)
        * (1. - tanh(pow(n / 5e16, 0.34)));
    double gehh = 1. + (564812. * pow(t, -1.6546) - 1.)
        * (1. - tanh(pow(p / 5e16, 0.29)));
    double Cehh = 7.91e-32 - 4.13e-35 * t + 3.59e-37 * t * t;
    double r = (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad)
        * (n * p - nie * nie);
    if (r < 0.0) {
        drdn = 0.0;
    } else {
        drdn = Ceeh * geeh * (n * p - nie * nie)
            + (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad) * p;
    }
    #endif
}

void Auger_Recombination::Compute_drdp(const double t, const double n,
    const double p, const double nie, const double f, double& drdp) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdp = 0.0;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 1997Altermatt (10.1063/1.366360), Eqs. (5) - (6)
    double geeh = 1. + (235548. * pow(t, -1.5013) - 1.)
        * (1. - tanh(pow(n / 5e16, 0.34)));
    double gehh = 1. + (564812. * pow(t, -1.6546) - 1.)
        * (1. - tanh(pow(p / 5e16, 0.29)));
    double Cehh = 7.91e-32 - 4.13e-35 * t + 3.59e-37 * t * t;
    double r = (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad)
        * (n * p - nie * nie);
    if (r < 0.0) {
        drdp = 0.0;
    } else {
        drdp = Cehh * gehh * (n * p - nie * nie)
            + (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad) * n;
    }
    #endif
}

void Auger_Recombination::Compute_drdnie(const double t, const double n,
    const double p, const double nie, const double f, double& drdnie) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdnie = 0.0;
    #else

    // 2014Nguyen, Eq. (3) and 2021Fell, Eq. (10): Brad = Blow * Brel
    double Brad = pow(10., -176.98 + 2.68812 * t - 0.018137 * t * t
        + 6.56769e-5 * pow(t, 3) - 1.21382e-7 * pow(t, 4)
        + 8.99086e-11 * pow(t, 5)) / nie / nie;

    // 1997Altermatt (10.1063/1.366360), Eqs. (5) - (6)
    double geeh = 1. + (235548. * pow(t, -1.5013) - 1.)
        * (1. - tanh(pow(n / 5e16, 0.34)));
    double gehh = 1. + (564812. * pow(t, -1.6546) - 1.)
        * (1. - tanh(pow(p / 5e16, 0.29)));
    double Cehh = 7.91e-32 - 4.13e-35 * t + 3.59e-37 * t * t;
    double r = (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad)
        * (n * p - nie * nie);
    if (r < 0.0) {
        drdnie = 0.0;
    } else {
        drdnie = (Ceeh * geeh * n + Cehh * gehh * p + (1. - fPR) * Brad)
            * (- 2.0 * nie);
    }
    #endif
}

void Auger_Recombination::Compute_drdf(const double t, const double n,
    const double p, const double nie, const double f, double& drdf) {
    #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

    // test case for dependence on electric field
    drdf = -1e15 * 2.0 * f;
    #else

    // Auger recombination
    drdf = 0.0;
    #endif
}

extern "C" {
    PMI_Recombination* new_PMI_Recombination(const PMI_Environment& env) {
        return new Auger_Recombination(env);
    }

    int PMI_Recombination_ElectricField() {
        #ifdef PMI_RECOMB_TEST_ELECTRIC_FIELD_DEPENDENCE

        // test case for dependence on electric field
        return 1;
        #else

        // Auger recombination
        // model does not depend on electric field
        return 0;
        #endif
    }
}
