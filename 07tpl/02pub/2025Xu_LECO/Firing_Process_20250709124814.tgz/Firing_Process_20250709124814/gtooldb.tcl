
# There are three tool databases: global, user and project. The global
# 'tooldb.tcl' can be found under $STROOT_LIB/glib2; The user
# 'tooldb_z3505796 is located at $STDB; The project 'gtooldb.tcl' is located
# the project directory.
# If 'gtooldb.tcl' is present in a project, it may be loaded if no prior one
# gets loaded. From several tests, it seems 'swb' needs restart to load the
# desired 'gtooldb.tcl'.
# The following modification would execute '11ctrlsim.tcl' everytime the save
# button is pressed.
namespace eval ::G_project {
    if {[info procs Save] eq "Save" && [info procs _Save] ne "_Save"} {
        rename Save _Save
        proc Save {} {
            _Save

            # 'pwd' is the directory where 'swb' starts
            # 'WDir' is the project directory you're working on
            cd [WDir]
            if {[file isfile 11ctrlsim.tcl]} {
                exec tclsh 11ctrlsim.tcl -i -a
            }
        }
    }
}