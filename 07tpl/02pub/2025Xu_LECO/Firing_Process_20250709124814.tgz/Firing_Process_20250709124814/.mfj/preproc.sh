#!/bin/bash

STROOT=/srv/scratch/z3505796/apps/sentaurus/T-2022.03
export STROOT
STRELEASE=T-2022.03
export STRELEASE
STROOT_LIB=/srv/scratch/z3505796/apps/sentaurus/T-2022.03/tcad/current/lib
export STROOT_LIB
[[ -z $LM_LICENSE_FILE ]] && {
    LM_LICENSE_FILE=27020@license2e.restech.unsw.edu.au
    export LM_LICENSE_FILE
}
LD_LIBRARY_PATH=/srv/scratch/z3505796/apps/sentaurus/sharedlib
export LD_LIBRARY_PATH
[[ -z $STDB ]] && {
    [[ -d ~/STDB ]] || mkdir ~/STDB
    STDB=~/STDB && export STDB
}

$STROOT/bin/gcleanup -default .
$STROOT/bin/spp -verbose -i .
