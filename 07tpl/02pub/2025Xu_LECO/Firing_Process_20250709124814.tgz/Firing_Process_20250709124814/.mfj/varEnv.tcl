# --- Tcl environment variables for Sentaurus TCAD

    set mfjDfltSet  {2.0 0.8 0.1 !Node4All ColMode !FullSchenk 100 10 0.001 4
        {64 80 128 256} {5 5 6 10} {1e-10 1e-12 1e-15 1e-25} {10 12 15 20}}

    set mfjRegInfo  {{{{Gas 0_Gas Insulator 0} -0.1 0} {{SnO2 1_SnO2
        Semiconductor 1} 0 0.02} {{MAPbBr3 2_MAPbBr3 Semiconductor 2} 0.02 0.5}
        {{NiOx 3_NiOx Semiconductor 3} 0.5 0.51} {{Gold 4_Gold Conductor 4} 0.51
        0.511} {{SnO2 5_SnO2 Semiconductor 5} 0.511 0.531} {{MAPbI3 6_MAPbI3
        Semiconductor 6} 0.531 1.031} {{NiOx 7_NiOx Semiconductor 7} 1.031
        1.041} {{Gas 8_Gas Insulator 8} 1.041 1.141}}}

    set mfjSTLst    {sde sprocess sdevice svisual}

    set mfjModTime  {{.mfj/mfjGrm.tcl 1697288744} {.mfj/mfjIntrpr.tcl
        1697071597} {.mfj/mfjProc.tcl 1698061990} {.mfj/mfjST.tcl 1700517668}
        {01mdb/Gold_k0.par 1700601445} {01mdb/MAPbBr3_2022Ishteev.par
        1700597528} {01mdb/MAPbI3_2018Manzoor.par 1700594461}
        {01mdb/NiOx_2012Holman.par 1680514847} {01mdb/SnO2_2017Jiang.par
        1607339726} {02opt/AM1.5g_IEC60904-3_2008.txt 1680514855}
        {04code/pmi_Aug_Altermatt.C 1692325261} {04code/pmi_Aug_Niewelt.C
        1692325282} {04code/pmi_Aug_Richter.C 1692325305} {04code/pmi_OG1D.C
        1674906551} {11ctrlsim.tcl 1697923694} {Molefraction.txt 1688290012}
        {datexcodes.txt 1700595856} {sde_dvs.cmd 1698105334} {sdevice.par
        1698104390} {sdevice_des.cmd 1699884428} {sprocess_fps.cmd 1699341259}
        {svisual_vis.tcl 1699922371}}

    set SimEnv      {Sentaurus T-2022.03 !Cylindrical Electrical Local}

