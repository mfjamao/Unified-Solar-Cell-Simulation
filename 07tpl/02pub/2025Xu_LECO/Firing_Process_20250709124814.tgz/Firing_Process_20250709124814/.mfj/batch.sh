#!/bin/bash

#PBS -N pbs
#PBS -l walltime=1:00:00
#PBS -l mem=20gb
#PBS -l ncpus=4
#PBS -k oed
#PBS -j oe
#PBS -m bea
#PBS -M z3505796@unsw.edu.au

STROOT=/srv/scratch/z3505796/apps/sentaurus/T-2022.03
export STROOT
STRELEASE=T-2022.03
export STRELEASE
STROOT_LIB=/srv/scratch/z3505796/apps/sentaurus/T-2022.03/tcad/current/lib
export STROOT_LIB
[[ -z $LM_LICENSE_FILE ]] && {
    LM_LICENSE_FILE=27020@license2e.restech.unsw.edu.au
    export LM_LICENSE_FILE
}
LD_LIBRARY_PATH=/srv/scratch/z3505796/apps/sentaurus/sharedlib
export LD_LIBRARY_PATH
[[ -z $STDB ]] && {
    [[ -d ~/STDB ]] || mkdir ~/STDB
    STDB=~/STDB && export STDB
}

cd /home/z3505796/STDB/05Tests/SolarCellSim
$STROOT/bin/gsub -verbose -e "all" . 
