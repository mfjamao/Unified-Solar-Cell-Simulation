#if "@tool_label@" eq "sde"

    set RegGen          {{SnO2 0.02} {MAPbBr3 0.48} {NiOx 0.01} {Gold 0.001}
        {SnO2 0.02} {MAPbI3 0.5} {NiOx 0.01}}

    set FldAttr         {{r1 P 3.3e+18} {r5 P 3.3e+18} {r2 P 1e+16} {r6 P 1e+16}
        {r3 B 2.85e+17} {r7 B 2.85e+17}}

    set IntfAttr        {{r0/1 c1 Ohmic 0 0 0 1e7} {r7/8 c0 Ohmic 0 0 0 1e7}}

    set GopAttr         {{r0/1 OBAM} {Spectrum 02opt/AM1.5g_IEC60904-3_2008.txt
        0.3 1.2 0.01}}

    set DfltAttr        {{Mesh 0.1 0.01 8 0.001 8 1.5 0.001 1.1} {Numeric 128}
        {Other 25}}

#endif

#if "@tool_label@" eq "sprocess"

    set ProcSeq         {}

#endif

#if "@tool_label@" eq "sdevice"

    set ModPar          {{r1 01mdb/SnO2_2017Jiang.par SRH 1e-12 mt 0.1} {r5
        01mdb/SnO2_2017Jiang.par SRH 1e-12 mt 0.1} {r2
        01mdb/MAPbBr3_2022Ishteev.par SRH 1e-06} {r4 01mdb/Gold_k0.par} {r6
        01mdb/MAPbI3_2018Manzoor.par SRH 1e-06} {r3 01mdb/NiOx_2012Holman.par
        SRH 1e-12 mt 0.1} {r7 01mdb/NiOx_2012Holman.par SRH 1e-12 mt 0.1}}

    set VarVary         {{SpecScaling 1 0} {c0 2.5 250}}

    set GetFld          {{p0 1 1 Band}}

#endif

#if "@tool_label@" eq "svisual"

    set PPAttr          {{v1 JV}}

#endif
