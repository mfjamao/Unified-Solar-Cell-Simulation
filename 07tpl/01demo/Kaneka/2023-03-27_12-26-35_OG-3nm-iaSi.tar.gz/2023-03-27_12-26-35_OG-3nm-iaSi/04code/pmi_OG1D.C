// This PMI was extended from the CurrentPlot PMI in M.2016.12. In addition
// to 3D to 1D conversion, 2D to 1D absorption conversion is implemented.
// It is slightly faster than the original (~ 2 s for each wavelength)
// Modified by Dr. Fa-Jun MA (mfjamao@yahoo.com)

#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include "PMIModels.h"


/*  PMI_CurrentPlot is derived from PMI_Device_Interface. It is an abstract
    class with three pure virtual functions for dataset, function and plots.
    PMI_Device_Interface is derived from PMI_Device_Common_Base, which has
    functions like InitParameter, Mesh, etc. Similar public functions can
    also be found in base class PMI_Vertex_Common_Base*/
class OGTo1D : public PMI_CurrentPlot {
    private:

        // des_bulk is derived from class des_region; des_mesh is a base class
        typedef std::vector<des_bulk*> des_bulk_vector;
        des_bulk_vector regLst;
        const des_mesh* mesh;

        // user-defined variables
        double grid1st, scaling;
        const char* nodeOutput;
    public:
        OGTo1D (const PMI_Device_Environment& env);
        ~OGTo1D ();

        // Override virtual functions below
        void Compute_Dataset_Names (des_string_vector& dataset);
        void Compute_Function_Names (des_string_vector& function);
        void Compute_Plot_Values (des_double_vector& value);
};

OGTo1D::OGTo1D (const PMI_Device_Environment& env) : PMI_CurrentPlot (env) {

    // Mesh () is a public function in base class PMI_Device_Common_Base,
    // which returns the whole device mesh
    mesh = Mesh ();

    // size_t: Unsigned integer type defined in 'stdlib.h'
    // Visit all the regions and keep those silicon material regions
    for (size_t idx0 = 0; idx0 < mesh->size_region (); idx0++) {
        des_region* reg = mesh->region (idx0);

        // des_region has two types: bulk and contact
        if (reg->type () == des_region::bulk) {

            // With dynamic_cast, type conversion with a pointer is executed at
            // runtime. D2B is simple while B2D requires the base class is
            // a polymorphic type
            des_bulk* bulk = dynamic_cast <des_bulk*> (reg);

            // The individual values of an enumeration are scoped not only
            // within the enumeration but also at the same level as the
            // enumeration itself. des_bulk::des_mateialgroup::semiconductor
            // is equivalent to des_bulk::semiconductor
            if (bulk->materialgroup () == des_bulk::semiconductor) {

                // 'regions' is a private member vector with type des_bulk
                regLst.push_back (bulk);
            }
        }
    }

    // grid1st and scaling can be adjusted to control the 1D grid
    grid1st = InitParameter ("grid_start", 0.001);  // um
    scaling = InitParameter ("scaling", 1.05);
    nodeOutput = InitStringParameter ("node_output", "n0_OG1D.plx");
}

OGTo1D::~OGTo1D () {
}

// typedef std::vector<std::string> des_string_vector;
void OGTo1D::Compute_Dataset_Names (des_string_vector& dataset) {
    dataset.push_back ("1D_OpticalGeneration");
}

void OGTo1D::Compute_Function_Names (des_string_vector& function) {
    function.push_back ("1D_OpticalGeneration");
}

void OGTo1D::Compute_Plot_Values (des_double_vector& value) {
    clock_t tStart = clock();

    // Data () is a public function in the previous class PMI_Device_Interface,
    // which returns the whole device data
    des_data* data = Data ();

    // ReadMeasure gets a 2D array [element index][local element-vertex index]:
    // with voronoi volume (3D), area (2D), length (1D) [um]
    const double*const* measure = data->ReadMeasure ();

    // ReadScalar gets a 1D array [location index] with scalar data
    // Since its argument is vertex, the array is indexed by vertex id
    const double *intfDist = data->ReadScalar (des_data::vertex,
        "InterfaceDistance"); // [um]
    const double *OG = data->ReadScalar (des_data::vertex,
        "OpticalGeneration"); // [cm^-3s^-1]

    // A six-column 2D array will be created to hold depth related data
    // Column 0: the depth value (based on grid1st and scalcing) [um]
    // Column 1: the low bound of Sk, midpoint between k and k-1 [um]
    // Column 2: the high bound of Sk, midpoint between k and k+1 [um]
    // Column 3: the voronoi length (Sk) at each depth [um]
    // Column 4: the total voronoi volume at each depth [um^3]
    // Column 5: the integral of optical generation [s^-1]
    // In 2D, assume the 3rd dimension is 1 um
    double* depArr = NULL, grid;
    size_t depLen, len, idx = 0;
    double optGen = 0, normOptGen = 0, loOverlap, hiOverlap, sOverlap;
    double intOG = 0, sumVol = 0, d2i = 0, maxd2i = 0, vtxVol;
    double dMin, dMax, yMin = 0, yMax = 0, zMin = 0, zMax = 0, area;
    std::ofstream outFile;
    std::ifstream inFile;
    std::string str, title;
    char chr;
    const size_t dim = mesh->dim();

    // Find the max distance to interface in the structure by
    // checking each vertex of semiconductor regions. Additionally,
    // update yMin, yMax and zMin and zMax if 3D
    for (size_t idx0 = 0; idx0 < regLst.size(); idx0++) {
        des_bulk* reg = regLst[idx0];
        for (size_t idx1 = 0; idx1 < reg->size_vertex(); idx1++) {
            des_vertex* vtx = reg->vertex (idx1);
            d2i = intfDist[vtx->index()];
            if (maxd2i < d2i) maxd2i = d2i;
            if (yMin > vtx->coord()[1]) yMin = vtx->coord()[1];
            if (yMax < vtx->coord()[1]) yMax = vtx->coord()[1];
            if (dim == 3) {
                if (zMin > vtx->coord()[2]) zMin = vtx->coord()[2];
                if (zMax < vtx->coord()[2]) zMax = vtx->coord()[2];
            }
        }
    }

    // Surface area of the device [um*um]
    if (dim == 3) {
        area = (yMax-yMin)*(zMax-zMin);
        title = "# 3D to 1D Optical Generation Conversion";
    } else {
        area = yMax-yMin;
        title = "# 2D to 1D Optical Generation Conversion";
    }

    // Determine the number of rows to hold depth values
    depLen = 1;
    grid = grid1st;
    while (grid < maxd2i) {
        if (depLen > 1) grid = grid*scaling;
        depLen++;
    }

    // It is costly to create a dynamic 2D array. Instead, a 1D dynamic size
    // array is created instead with the size of depLen*6. It is accessed
    // in a way similar to 2D array
    // Initialise the array with depth, loSk, hiSk, Sk, vol, intOG
    depArr = new double[depLen*6];
    for (size_t idx0 = 0; idx0 < depLen; idx0++) {
        for (size_t idx1 = 0; idx1 < 6; idx1++) {
            if (idx0 == 0) {
                if (idx1 == 2 || idx1 == 3) {
                    depArr[idx0*6+idx1] = grid1st/2;
                } else {
                    depArr[idx0*6+idx1] = 0;
                }
            } else if (idx0 == 1 && (idx1 == 0 || idx1 == 1)) {
                if (idx1 == 0) {
                    depArr[idx0*6+idx1] = grid1st;
                } else {
                    depArr[idx0*6+idx1] = grid1st/2;
                }
            } else if (idx0 == (depLen-1)) {
                if (idx1 == 0) {
                    depArr[idx0*6+idx1] = maxd2i;
                } else if (idx1 == 1) {
                    depArr[idx0*6+idx1] = (maxd2i+depArr[(idx0-1)*6])/2;
                } else if (idx1 == 2) {
                    depArr[idx0*6+idx1] = maxd2i;
                    depArr[(idx0-1)*6+idx1] = depArr[idx0*6+1];
                } else if (idx1 == 3) {
                    depArr[idx0*6+idx1] = (maxd2i-depArr[(idx0-1)*6])/2;
                    depArr[(idx0-1)*6+idx1] = depArr[(idx0-1)*6+2]
                        -depArr[(idx0-1)*6+1];
                } else {
                    depArr[idx0*6+idx1] = 0;
                }
            } else {
                if (idx1 == 0) {// depth
                    depArr[idx0*6+idx1] = depArr[(idx0-1)*6+idx1]*scaling;
                } else if (idx1 == 1) {// loSk
                    depArr[idx0*6+idx1] = (depArr[idx0*6]+depArr[(idx0-1)*6])/2;
                } else if (idx1 == 2) {// previous hiSk == loSk
                    depArr[(idx0-1)*6+idx1] = depArr[idx0*6+1];
                } else if (idx1 == 3) {// previous Sk
                    depArr[(idx0-1)*6+idx1] = depArr[(idx0-1)*6+2]
                        -depArr[(idx0-1)*6+1];
                } else {
                    depArr[idx0*6+idx1] = 0;
                }
            }
        }
    }

    // Go through each vertex in each semiconductor region
    for (size_t idx0 = 0; idx0 < regLst.size(); idx0++) {
        des_bulk* reg = regLst[idx0];
        for (size_t idx1 = 0; idx1 < reg->size_vertex(); idx1++) {
            des_vertex* vtx = reg->vertex (idx1);

            // Read its distance to the semiconductor/dielectric interface,
            // and OpticalGeneration
            d2i = intfDist[vtx->index()]; // [um]
            optGen = OG[vtx->index()]; // [cm^-3s^-1]

            // Find each element this vertex belongs to
            for (size_t idx2 = 0; idx2 < vtx->size_element (); idx2++) {
                des_element* elm = vtx->element (idx2);

                // Only consider elements within the same region as the vertex
                if (elm->bulk() != reg) continue;

                // Identify this vertex among all vertices of this element
                for (size_t idx3 = 0; idx3 < elm->size_vertex (); idx3++) {
                    des_vertex* elmVtx = elm->vertex (idx3);
                    if (vtx->equal_coord(elmVtx)) {

                        // The unit of voronoi volume is um^3. m is at the
                        // local scope, so it has to be assigned to vtxVol
                        const double m = measure[elm->index ()] [idx3];
                        vtxVol = m;
                        intOG += vtxVol*optGen*1e-12; // [s^-1]
                        sumVol += vtxVol; // [um^3]
                    }
                }

                // Skip elements with 0 voronoi volume
                if (vtxVol == 0) continue;

                // Visit each edge of an element to determine dMin and dMax
                dMax = d2i;
                dMin = d2i;
                for (size_t idx3 = 0; idx3 < elm->size_edge(); idx3++) {
                    des_edge* edg = elm->edge (idx3);
                    des_vertex* edgSt = edg->start();
                    des_vertex* edgEnd = edg->end();
                    if (vtx->equal_coord(edgSt)) {
                        if (dMax < intfDist[edgEnd->index()])
                            dMax = intfDist[edgEnd->index()];
                        if (dMin > intfDist[edgEnd->index()])
                            dMin = intfDist[edgEnd->index()];
                    } else if (vtx->equal_coord(edgEnd)) {
                        if (dMax < intfDist[edgSt->index()])
                            dMax = intfDist[edgSt->index()];
                        if (dMin > intfDist[edgSt->index()])
                            dMin = intfDist[edgSt->index()];
                    }
                }

                // dMax and dMin found in the previous step are Delaunay
                // mesh points instead. Convert them into Voronoi vertices
                // for the Voronoi element.
                if (dMax != dMin) {
                    dMax = (dMax+d2i)*0.5;
                    dMin = (dMin+d2i)*0.5;
                } else {

                    // Suppose the other vertices of a tetrahedron are
                    // parallel to the surface, dMax =  dMin
                    // Projection of voronoi volume: Cube and square root
                    // std::cout << reg->name() << " vertex " << idx1
                    //    << ": dMax = dMin = " << dMax <<std::endl;
                    if (dim == 3) {

                        // One third needs to be 1./3, otherwise it's 0
                        dMax = d2i+pow(vtxVol, 1./3);
                    } else {
                        dMax = d2i+pow(vtxVol, 1./2);
                    }
                }

                // Find the overlap of this element to each depth
                for (size_t idx3 = 0; idx3 < depLen; idx3++) {

                    // Update depArr with possible overlaps
                    if ((dMax > depArr[idx3*6+1])
                        && (dMin < depArr[idx3*6+2])) {
                        loOverlap = std::max(depArr[idx3*6+1], dMin);
                        hiOverlap = std::min(depArr[idx3*6+2], dMax);

                        // If vtxVol = 0, dMax may be equal to dMin
                        if (dMax == dMin) {
                            if (vtxVol != 0) {
                                if (dim == 3) {
                                    sOverlap = (hiOverlap-loOverlap)
                                        /pow(vtxVol, 1./3);
                                } else {
                                    sOverlap = (hiOverlap-loOverlap)
                                        /pow(vtxVol, 1./2);
                                }
                            } else {

                                // Original:
                                // sOverlap = (hiOverlap-loOverlap)/1e-10;
                                // Not sure why?? But it should be 0!
                                sOverlap = 0;
                            }
                        } else {
                            sOverlap = (hiOverlap-loOverlap)/(dMax-dMin);
                        }
                        depArr[idx3*6+4] += vtxVol*sOverlap;
                        depArr[idx3*6+5] += 1e-12*optGen*vtxVol*sOverlap;
                    }
                }
            } // end of element loop
        }  // end of vertex loop
    }  // end of bulk loop
    std::cout << "Total Optical Generation (vertex) = "
        << 1.602e-8*intOG/area << " mA/cm^2\n";

    // If the output file does not exist, output the whole array; otherwise,
    // output only normalised optical generation under append mode
    inFile.open(nodeOutput);
    if (inFile.is_open()) {

        // Set the position to the end and get the file size
        inFile.seekg(0, std::ios::end);
        len = inFile.tellg();
        for (size_t idx0 = 1; idx0 < len; idx0++) {
            inFile.seekg(-idx0, std::ios::end);
            inFile.get(chr);

            // Exit once the first space is found
            if (chr == ' ') break;
            if (chr >= '0' && chr <= '9') str.insert(str.begin(), chr);
        }
        inFile.close();

        // Convert the string to a number using stringstream
        std::stringstream ss(str);
        ss >> idx;
        idx++;

        // Open output file under append mode
        outFile.open (nodeOutput, std::ios::app);
        outFile << "# Total Optical Generation (vertex) = "
            << 1.602e-8*intOG/area << " mA/cm^2\n";
        outFile << "# depth\taveOG\n";
        for (size_t idx0 = 0; idx0 < depLen; idx0++) {

            // Normalised optical generation
            if (depArr[idx0*6+3] > 0) {
                normOptGen = 1e12*depArr[idx0*6+5]/depArr[idx0*6+3]/area;
                outFile << depArr[idx0*6] << "\t" << normOptGen << std::endl;
            }
        }
    } else {
        outFile.open (nodeOutput);
        outFile << title << "\n";
        outFile << "# Surface area = " << area << " um^2\n";
        outFile << "# Total Optical Generation (vertex) = "
            << 1.602e-8*intOG/area << " mA/cm^2\n";
        outFile << "# Total Voronoi Volume (vertex) = " << sumVol << " um^3\n";
        intOG = 0;
        sumVol = 0;
        for (size_t idx0 = 0; idx0 < depLen; idx0++) {
            intOG += depArr[idx0*6+5];
            sumVol += depArr[idx0*6+4];
        }
        outFile << "# Total Optical Generation (depth) = "
            << 1.602e-8*intOG/area << " mA/cm^2\n";
        outFile << "# Total Voronoi Volume (depth) = " << sumVol << " um^3\n";
        outFile << "# depth\tlowSk\thighSk\tSk\tVor_Vol\tintOG\taveOG\n";
        for (size_t idx0 = 0; idx0 < depLen; idx0++) {
            for (size_t idx1 = 0; idx1 < 6; idx1++) {
                outFile << depArr[idx0*6+idx1] << "\t";
            }

            // Normalised optical generation
            if (depArr[idx0*6+3] > 0) {
                normOptGen = 1e12*depArr[idx0*6+5]/depArr[idx0*6+3]/area;
                outFile << normOptGen;
            }
            outFile << std::endl;
        }
    }
    outFile << "# End of wavelength varying step " << idx << "\n\n";
    outFile.close();
    delete[] depArr;
    value.push_back (intOG);    
    std::cout << "OG1D run time = "
        << 1e3*(double)(clock()-tStart)/CLOCKS_PER_SEC << " ms\n";
}

extern "C" {
    PMI_CurrentPlot* new_PMI_CurrentPlot (const PMI_Device_Environment& env) {
        return new OGTo1D (env);
    }
}

