DF-ISE text

Info {
  version   = 1.0
  type      = xyplot
  datasets  = [
    "time"
    "c0 OuterVoltage" "c0 InnerVoltage" "c0 QuasiFermiPotential" "c0 DisplacementCurrent" "c0 eCurrent"
    "c0 hCurrent" "c0 TotalCurrent" "c0 Charge" "c1 OuterVoltage" "c1 InnerVoltage"
    "c1 QuasiFermiPotential" "c1 DisplacementCurrent" "c1 eCurrent" "c1 hCurrent" "c1 TotalCurrent"
    "c1 Charge" "Device=,File=CommandFile/Physics,DefaultRegionPhysics,ModelParameter=Optics/Excitation/Wavelength" "AveWindow((5.006,0),(160.006,50)) DopingConcentration" "IntegrSemiconductor OpticalGeneration" "IntegrSemiconductor OpticalGenerationFromMonochromaticSource"
    "IntegrSemiconductor OpticalGenerationFromSpectrum" "IntegrSemiconductor OpticalGenerationFromSpectrumUnscaled" "AveSemiconductor OpticalGeneration" "AveSemiconductor OpticalGenerationFromMonochromaticSource" "AveSemiconductor OpticalGenerationFromSpectrum"
    "AveSemiconductor OpticalGenerationFromSpectrumUnscaled" "Integr01_iaSi OpticalGeneration" "Integr01_iaSi OpticalGenerationFromMonochromaticSource" "Integr01_iaSi OpticalGenerationFromSpectrum" "Integr01_iaSi OpticalGenerationFromSpectrumUnscaled"
    "Integr02_Silicon OpticalGeneration" "Integr02_Silicon OpticalGenerationFromMonochromaticSource" "Integr02_Silicon OpticalGenerationFromSpectrum" "Integr02_Silicon OpticalGenerationFromSpectrumUnscaled" "Integr03_iaSi OpticalGeneration"
    "Integr03_iaSi OpticalGenerationFromMonochromaticSource" "Integr03_iaSi OpticalGenerationFromSpectrum" "Integr03_iaSi OpticalGenerationFromSpectrumUnscaled" "Integr04_paSi OpticalGeneration" "Integr04_paSi OpticalGenerationFromMonochromaticSource"
    "Integr04_paSi OpticalGenerationFromSpectrum" "Integr04_paSi OpticalGenerationFromSpectrumUnscaled" "Integr05_naSi OpticalGeneration" "Integr05_naSi OpticalGenerationFromMonochromaticSource" "Integr05_naSi OpticalGenerationFromSpectrum"
    "Integr05_naSi OpticalGenerationFromSpectrumUnscaled" "IntegrSemiconductor AbsorbedPhotonDensity" "IntegrSemiconductor AbsorbedPhotonDensityFromMonochromaticSource" "IntegrSemiconductor AbsorbedPhotonDensityFromSpectrum" "Integr AbsorbedPhotonDensity"
    "Integr AbsorbedPhotonDensityFromMonochromaticSource" "Integr AbsorbedPhotonDensityFromSpectrum" "Integr01_iaSi AbsorbedPhotonDensity" "Integr01_iaSi AbsorbedPhotonDensityFromMonochromaticSource" "Integr01_iaSi AbsorbedPhotonDensityFromSpectrum"
    "Integr02_Silicon AbsorbedPhotonDensity" "Integr02_Silicon AbsorbedPhotonDensityFromMonochromaticSource" "Integr02_Silicon AbsorbedPhotonDensityFromSpectrum" "Integr03_iaSi AbsorbedPhotonDensity" "Integr03_iaSi AbsorbedPhotonDensityFromMonochromaticSource"
    "Integr03_iaSi AbsorbedPhotonDensityFromSpectrum" "Integr04_paSi AbsorbedPhotonDensity" "Integr04_paSi AbsorbedPhotonDensityFromMonochromaticSource" "Integr04_paSi AbsorbedPhotonDensityFromSpectrum" "Integr05_naSi AbsorbedPhotonDensity"
    "Integr05_naSi AbsorbedPhotonDensityFromMonochromaticSource" "Integr05_naSi AbsorbedPhotonDensityFromSpectrum" "IntegrSemiconductor AugerRecombination" "Integr01_iaSi AugerRecombination" "Integr02_Silicon AugerRecombination"
    "Integr03_iaSi AugerRecombination" "Integr04_paSi AugerRecombination" "Integr05_naSi AugerRecombination" "IntegrSemiconductor RadiativeRecombination" "Integr01_iaSi RadiativeRecombination"
    "Integr02_Silicon RadiativeRecombination" "Integr03_iaSi RadiativeRecombination" "Integr04_paSi RadiativeRecombination" "Integr05_naSi RadiativeRecombination" "IntegrSemiconductor eGapStatesRecombination"
    "Integr01_iaSi eGapStatesRecombination" "Integr02_Silicon eGapStatesRecombination" "Integr03_iaSi eGapStatesRecombination" "Integr04_paSi eGapStatesRecombination" "Integr05_naSi eGapStatesRecombination"
    "IntegrSemiconductor PMIRecombination" "Integr01_iaSi PMIRecombination" "Integr02_Silicon PMIRecombination" "Integr03_iaSi PMIRecombination" "Integr04_paSi PMIRecombination"
    "Integr05_naSi PMIRecombination" "IntegrSemiconductor srhRecombination" "Integr01_iaSi srhRecombination" "Integr02_Silicon srhRecombination" "Integr03_iaSi srhRecombination"
    "Integr04_paSi srhRecombination" "Integr05_naSi srhRecombination" "IntegrSemiconductor TotalRecombination" "Integr01_iaSi TotalRecombination" "Integr02_Silicon TotalRecombination"
    "Integr03_iaSi TotalRecombination" "Integr04_paSi TotalRecombination" "Integr05_naSi TotalRecombination" "Ave01_iaSi eDensity" "Ave02_Silicon eDensity"
    "Ave03_iaSi eDensity" "Ave04_paSi eDensity" "Ave05_naSi eDensity" "AveWindow((5.006,0),(160.006,50)) eDensity" "Ave01_iaSi EffectiveIntrinsicDensity"
    "Ave02_Silicon EffectiveIntrinsicDensity" "Ave03_iaSi EffectiveIntrinsicDensity" "Ave04_paSi EffectiveIntrinsicDensity" "Ave05_naSi EffectiveIntrinsicDensity" "AveWindow((5.006,0),(160.006,50)) EffectiveIntrinsicDensity"
    "Ave01_iaSi hDensity" "Ave02_Silicon hDensity" "Ave03_iaSi hDensity" "Ave04_paSi hDensity" "Ave05_naSi hDensity"
    "AveWindow((5.006,0),(160.006,50)) hDensity" "Integr00_Gas/01_iaSi SurfaceRecombination" "Integr04_paSi/07_Gas SurfaceRecombination" "Integr05_naSi/07_Gas SurfaceRecombination" "Integr01_iaSi/02_Silicon SurfaceRecombination"
    "Integr03_iaSi/02_Silicon SurfaceRecombination" ]
  functions = [
    Time
    OuterVoltage InnerVoltage QuasiFermiPotential DisplacementCurrent eCurrent
    hCurrent TotalCurrent Charge OuterVoltage InnerVoltage
    QuasiFermiPotential DisplacementCurrent eCurrent hCurrent TotalCurrent
    Charge ModelParameter DopingConcentration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AugerRecombination AugerRecombination AugerRecombination
    AugerRecombination AugerRecombination AugerRecombination RadiativeRecombination RadiativeRecombination
    RadiativeRecombination RadiativeRecombination RadiativeRecombination RadiativeRecombination eGapStatesRecombination
    eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination
    PMIRecombination PMIRecombination PMIRecombination PMIRecombination PMIRecombination
    PMIRecombination srhRecombination srhRecombination srhRecombination srhRecombination
    srhRecombination srhRecombination TotalRecombination TotalRecombination TotalRecombination
    TotalRecombination TotalRecombination TotalRecombination eDensity eDensity
    eDensity eDensity eDensity eDensity EffectiveIntrinsicDensity
    EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity
    hDensity hDensity hDensity hDensity hDensity
    hDensity SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination ]
}

Data {
      0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   8.59817427480429E-27
     -4.06022961353867E-09  -4.06022961353867E-09  -8.57530928216530E-18   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   4.06022961353920E-09  -5.27311181638037E-22   4.06022961353867E-09
      8.57530928284725E-18   3.00000000000000E-01   1.56000000000008E+15   3.98204187831376E+14   0.00000000000000E+00
      3.98204187831376E+14   1.32734729277118E+15   4.82578151911599E+18   0.00000000000000E+00   4.82578151911599E+18
      1.60859383970524E+19   1.14032194076026E+13   0.00000000000000E+00   1.14032194076026E+13   3.80107313586753E+13
      3.86800968423770E+14   0.00000000000000E+00   3.86800968423770E+14   1.28933656141253E+15   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   1.33302395588411E+15   5.67666311290319E+12   1.32734729277118E+15   1.33428704440253E+15
      5.72690021669177E+12   1.32856014418581E+15   4.07350913586741E+13   2.72436000000000E+12   3.80107313586753E+13
      1.29228886452543E+15   2.95230311290318E+12   1.28933656141253E+15   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   5.97774992660451E+10
      5.97774880621207E+10   0.00000000000000E+00   5.22587213602388E+03   1.35530175736812E+03   4.62275085391594E+03
      1.94081193641221E+10   0.00000000000000E+00   1.94081193641221E+10   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   2.91328705027554E+11   0.00000000000000E+00   2.91328705027554E+11   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00  -3.97832331421887E+14  -1.13434419135041E+13  -3.86488889519584E+14
      5.22587324455476E+03   1.35537334716730E+03   4.62280824636045E+03   6.48027861361955E+11   1.58694727353194E+15
      3.75542361756753E+14   7.22821793720263E+01   4.79591928296101E+16   1.59186607394030E+15   3.18024054424232E+05
      8.54639971714365E+09   3.18024054424229E+05   3.18024054424227E+05   1.20191131746345E+05   8.54639971714474E+09
      4.76803349327302E+09   7.16736507202553E+13   8.94508134618111E+12   9.18533348892781E+14   3.71110278455500E+03
      3.18660857521719E+13   0.00000000000000E+00   7.75802503610380E+03   6.21948962942134E+03   1.44416424333729E+14
      2.48842627759506E+08
      1.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   8.74974155830342E-27
     -4.13110768472851E-09  -4.13110768472851E-09  -8.57560250786517E-18   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   4.13110768472645E-09   2.06951982410172E-21   4.13110768472852E-09
      8.57560250827613E-18   3.00000000000000E-01   1.56000000000008E+15   4.03880850944264E+14   5.67666311290319E+12
      3.98204187831376E+14   1.32734729277118E+15   4.89457621484637E+18   6.87946957305634E+16   4.82578151911599E+18
      1.60859383970524E+19   1.41275794076024E+13   2.72436000000000E+12   1.14032194076026E+13   3.80107313586753E+13
      3.89753271536665E+14   2.95230311290318E+12   3.86800968423770E+14   1.28933656141253E+15   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   1.33302395588411E+15   5.67666311290319E+12   1.32734729277118E+15   1.33428704440253E+15
      5.72690021669177E+12   1.32856014418581E+15   4.07350913586741E+13   2.72436000000000E+12   3.80107313586753E+13
      1.29228886452543E+15   2.95230311290318E+12   1.28933656141253E+15   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   7.26615139231050E+10
      7.26615025224903E+10   0.00000000000000E+00   5.31677547992691E+03   1.37997378887272E+03   4.70386544153363E+03
      1.97950842841066E+10   0.00000000000000E+00   1.97950842841066E+10   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   2.96722904533341E+11   0.00000000000000E+00   2.96722904533341E+11   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00  -4.03490317886282E+14  -1.40549178978809E+13  -3.89435399999798E+14
      5.31677660780650E+03   1.38004668335208E+03   4.70392387836736E+03   6.66311643113811E+11   1.58756940944838E+15
      3.75541936775911E+14   7.23290218622970E+01   4.79591796264054E+16   1.59247030687608E+15   3.18024054424232E+05
      8.54639971714365E+09   3.18024054424229E+05   3.18024054424227E+05   1.20191131746345E+05   8.54639971714474E+09
      5.86285988794714E+09   7.22846616945694E+13   8.93990051488996E+12   9.18439552414955E+14   3.71212183303091E+03
      3.24703187210576E+13   0.00000000000000E+00   7.89941028418327E+03   6.33266773160783E+03   1.45650661268131E+14
      2.53170699403324E+08
}
