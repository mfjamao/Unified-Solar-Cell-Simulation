DF-ISE text

Info {
  version   = 1.0
  type      = xyplot
  datasets  = [
    "time"
    "c0 OuterVoltage" "c0 InnerVoltage" "c0 QuasiFermiPotential" "c0 DisplacementCurrent" "c0 eCurrent"
    "c0 hCurrent" "c0 TotalCurrent" "c0 Charge" "c1 OuterVoltage" "c1 InnerVoltage"
    "c1 QuasiFermiPotential" "c1 DisplacementCurrent" "c1 eCurrent" "c1 hCurrent" "c1 TotalCurrent"
    "c1 Charge" "Device=,File=CommandFile/Physics,DefaultRegionPhysics,ModelParameter=Optics/Excitation/Wavelength" "AveWindow((5.006,0),(160.006,50)) DopingConcentration" "IntegrSemiconductor OpticalGeneration" "IntegrSemiconductor OpticalGenerationFromMonochromaticSource"
    "IntegrSemiconductor OpticalGenerationFromSpectrum" "IntegrSemiconductor OpticalGenerationFromSpectrumUnscaled" "AveSemiconductor OpticalGeneration" "AveSemiconductor OpticalGenerationFromMonochromaticSource" "AveSemiconductor OpticalGenerationFromSpectrum"
    "AveSemiconductor OpticalGenerationFromSpectrumUnscaled" "Integr01_iaSi OpticalGeneration" "Integr01_iaSi OpticalGenerationFromMonochromaticSource" "Integr01_iaSi OpticalGenerationFromSpectrum" "Integr01_iaSi OpticalGenerationFromSpectrumUnscaled"
    "Integr02_Silicon OpticalGeneration" "Integr02_Silicon OpticalGenerationFromMonochromaticSource" "Integr02_Silicon OpticalGenerationFromSpectrum" "Integr02_Silicon OpticalGenerationFromSpectrumUnscaled" "Integr03_iaSi OpticalGeneration"
    "Integr03_iaSi OpticalGenerationFromMonochromaticSource" "Integr03_iaSi OpticalGenerationFromSpectrum" "Integr03_iaSi OpticalGenerationFromSpectrumUnscaled" "Integr04_paSi OpticalGeneration" "Integr04_paSi OpticalGenerationFromMonochromaticSource"
    "Integr04_paSi OpticalGenerationFromSpectrum" "Integr04_paSi OpticalGenerationFromSpectrumUnscaled" "Integr05_naSi OpticalGeneration" "Integr05_naSi OpticalGenerationFromMonochromaticSource" "Integr05_naSi OpticalGenerationFromSpectrum"
    "Integr05_naSi OpticalGenerationFromSpectrumUnscaled" "IntegrSemiconductor AbsorbedPhotonDensity" "IntegrSemiconductor AbsorbedPhotonDensityFromMonochromaticSource" "IntegrSemiconductor AbsorbedPhotonDensityFromSpectrum" "Integr AbsorbedPhotonDensity"
    "Integr AbsorbedPhotonDensityFromMonochromaticSource" "Integr AbsorbedPhotonDensityFromSpectrum" "Integr01_iaSi AbsorbedPhotonDensity" "Integr01_iaSi AbsorbedPhotonDensityFromMonochromaticSource" "Integr01_iaSi AbsorbedPhotonDensityFromSpectrum"
    "Integr02_Silicon AbsorbedPhotonDensity" "Integr02_Silicon AbsorbedPhotonDensityFromMonochromaticSource" "Integr02_Silicon AbsorbedPhotonDensityFromSpectrum" "Integr03_iaSi AbsorbedPhotonDensity" "Integr03_iaSi AbsorbedPhotonDensityFromMonochromaticSource"
    "Integr03_iaSi AbsorbedPhotonDensityFromSpectrum" "Integr04_paSi AbsorbedPhotonDensity" "Integr04_paSi AbsorbedPhotonDensityFromMonochromaticSource" "Integr04_paSi AbsorbedPhotonDensityFromSpectrum" "Integr05_naSi AbsorbedPhotonDensity"
    "Integr05_naSi AbsorbedPhotonDensityFromMonochromaticSource" "Integr05_naSi AbsorbedPhotonDensityFromSpectrum" "IntegrSemiconductor AugerRecombination" "Integr01_iaSi AugerRecombination" "Integr02_Silicon AugerRecombination"
    "Integr03_iaSi AugerRecombination" "Integr04_paSi AugerRecombination" "Integr05_naSi AugerRecombination" "IntegrSemiconductor RadiativeRecombination" "Integr01_iaSi RadiativeRecombination"
    "Integr02_Silicon RadiativeRecombination" "Integr03_iaSi RadiativeRecombination" "Integr04_paSi RadiativeRecombination" "Integr05_naSi RadiativeRecombination" "IntegrSemiconductor eGapStatesRecombination"
    "Integr01_iaSi eGapStatesRecombination" "Integr02_Silicon eGapStatesRecombination" "Integr03_iaSi eGapStatesRecombination" "Integr04_paSi eGapStatesRecombination" "Integr05_naSi eGapStatesRecombination"
    "IntegrSemiconductor PMIRecombination" "Integr01_iaSi PMIRecombination" "Integr02_Silicon PMIRecombination" "Integr03_iaSi PMIRecombination" "Integr04_paSi PMIRecombination"
    "Integr05_naSi PMIRecombination" "IntegrSemiconductor srhRecombination" "Integr01_iaSi srhRecombination" "Integr02_Silicon srhRecombination" "Integr03_iaSi srhRecombination"
    "Integr04_paSi srhRecombination" "Integr05_naSi srhRecombination" "IntegrSemiconductor TotalRecombination" "Integr01_iaSi TotalRecombination" "Integr02_Silicon TotalRecombination"
    "Integr03_iaSi TotalRecombination" "Integr04_paSi TotalRecombination" "Integr05_naSi TotalRecombination" "Ave01_iaSi eDensity" "Ave02_Silicon eDensity"
    "Ave03_iaSi eDensity" "Ave04_paSi eDensity" "Ave05_naSi eDensity" "AveWindow((5.006,0),(160.006,50)) eDensity" "Ave01_iaSi EffectiveIntrinsicDensity"
    "Ave02_Silicon EffectiveIntrinsicDensity" "Ave03_iaSi EffectiveIntrinsicDensity" "Ave04_paSi EffectiveIntrinsicDensity" "Ave05_naSi EffectiveIntrinsicDensity" "AveWindow((5.006,0),(160.006,50)) EffectiveIntrinsicDensity"
    "Ave01_iaSi hDensity" "Ave02_Silicon hDensity" "Ave03_iaSi hDensity" "Ave04_paSi hDensity" "Ave05_naSi hDensity"
    "AveWindow((5.006,0),(160.006,50)) hDensity" "Integr00_Gas/01_iaSi SurfaceRecombination" "Integr04_paSi/07_Gas SurfaceRecombination" "Integr05_naSi/07_Gas SurfaceRecombination" "Integr01_iaSi/02_Silicon SurfaceRecombination"
    "Integr03_iaSi/02_Silicon SurfaceRecombination" ]
  functions = [
    Time
    OuterVoltage InnerVoltage QuasiFermiPotential DisplacementCurrent eCurrent
    hCurrent TotalCurrent Charge OuterVoltage InnerVoltage
    QuasiFermiPotential DisplacementCurrent eCurrent hCurrent TotalCurrent
    Charge ModelParameter DopingConcentration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration OpticalGeneration
    OpticalGeneration AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity AbsorbedPhotonDensity
    AbsorbedPhotonDensity AbsorbedPhotonDensity AugerRecombination AugerRecombination AugerRecombination
    AugerRecombination AugerRecombination AugerRecombination RadiativeRecombination RadiativeRecombination
    RadiativeRecombination RadiativeRecombination RadiativeRecombination RadiativeRecombination eGapStatesRecombination
    eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination eGapStatesRecombination
    PMIRecombination PMIRecombination PMIRecombination PMIRecombination PMIRecombination
    PMIRecombination srhRecombination srhRecombination srhRecombination srhRecombination
    srhRecombination srhRecombination TotalRecombination TotalRecombination TotalRecombination
    TotalRecombination TotalRecombination TotalRecombination eDensity eDensity
    eDensity eDensity eDensity eDensity EffectiveIntrinsicDensity
    EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity EffectiveIntrinsicDensity
    hDensity hDensity hDensity hDensity hDensity
    hDensity SurfaceRecombination SurfaceRecombination SurfaceRecombination SurfaceRecombination
    SurfaceRecombination ]
}

Data {
      0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   1.35491022586630E-26
     -6.36064661141363E-09  -6.36064661141363E-09  -8.58487121982925E-18   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   6.36064661141481E-09  -1.18415795617485E-21   6.36064661141363E-09
      8.58487121939074E-18   3.00000000000000E-01   1.56000000000008E+15   3.98204187831376E+14   0.00000000000000E+00
      3.98204187831376E+14   1.32734729277118E+15   4.82578151911599E+18   0.00000000000000E+00   4.82578151911599E+18
      1.60859383970524E+19   1.14032194076026E+13   0.00000000000000E+00   1.14032194076026E+13   3.80107313586753E+13
      3.86800968423770E+14   0.00000000000000E+00   3.86800968423770E+14   1.28933656141253E+15   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   1.33302395588411E+15   5.67666311290319E+12   1.32734729277118E+15   1.33428704440253E+15
      5.72690021669177E+12   1.32856014418581E+15   4.07350913586741E+13   2.72436000000000E+12   3.80107313586753E+13
      1.29228886452543E+15   2.95230311290318E+12   1.28933656141253E+15   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   2.54912082276934E+11
      2.54912064668952E+11   0.00000000000000E+00   8.17063364484339E+03   2.17432985404013E+03   7.26301891048845E+03
      3.28334030452296E+10   0.00000000000000E+00   3.28334030452296E+10   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   4.61855232592044E+11   0.00000000000000E+00   4.61855232592044E+11   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00  -3.97454585250383E+14  -1.11483061988596E+13  -3.86306279069126E+14
      8.17063538134138E+03   2.17444477343525E+03   7.26311096364200E+03   2.58798859649999E+16   1.65687750862743E+15
      3.75528571850052E+14   7.38361833749326E+01   4.79587645888003E+16   1.61138862426426E+15   3.18024054424232E+05
      8.54639971714365E+09   3.18024054424229E+05   3.18024054424227E+05   1.20191131746345E+05   8.54639971714474E+09
      1.63283629250674E+09   9.12507994148316E+13   8.77721400039476E+12   9.15465849093208E+14   3.74472922106813E+03
      5.13886375531272E+13   3.79925814077174E+11   1.24535555986677E+04   9.97559241402755E+03   7.77410396255151E+10
      3.89038601817924E+08
      1.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   1.37417322814964E-26
     -6.44903321022622E-09  -6.44903321022622E-09  -8.58524043897810E-18   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   6.44903321022678E-09  -5.72972294043384E-22   6.44903321022621E-09
      8.58524043823396E-18   3.00000000000000E-01   1.56000000000008E+15   4.03880850944264E+14   5.67666311290319E+12
      3.98204187831376E+14   1.32734729277118E+15   4.89457621484637E+18   6.87946957305634E+16   4.82578151911599E+18
      1.60859383970524E+19   1.41275794076024E+13   2.72436000000000E+12   1.14032194076026E+13   3.80107313586753E+13
      3.89753271536665E+14   2.95230311290318E+12   3.86800968423770E+14   1.28933656141253E+15   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   1.33302395588411E+15   5.67666311290319E+12   1.32734729277118E+15   1.33428704440253E+15
      5.72690021669177E+12   1.32856014418581E+15   4.07350913586741E+13   2.72436000000000E+12   3.80107313586753E+13
      1.29228886452543E+15   2.95230311290318E+12   1.28933656141253E+15   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   3.15813233888997E+11
      3.15813216034109E+11   0.00000000000000E+00   8.28354798495169E+03   2.20655875168673E+03   7.36478152107892E+03
      3.33471422279876E+10   0.00000000000000E+00   3.33471422279876E+10   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   4.68324132825619E+11   0.00000000000000E+00   4.68324132825619E+11   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00  -4.03063364287011E+14  -1.38117647741626E+13  -3.89251599530698E+14
      8.28354974557734E+03   2.20667537676638E+03   7.36487493770204E+03   2.58799045057223E+16   1.65762463483621E+15
      3.75528042131390E+14   7.38972910086727E+01   4.79587481452229E+16   1.61213517467240E+15   3.18024054424232E+05
      8.54639971714365E+09   3.18024054424229E+05   3.18024054424227E+05   1.20191131746345E+05   8.54639971714474E+09
      2.02293638927626E+09   9.20053401663051E+13   8.77077609217605E+12   9.15347024512604E+14   3.74604405560899E+03
      5.21351880337387E+13   4.70694300306334E+11   1.26383967834723E+04   1.01233485331148E+04   7.92004603152569E+10
      3.94413901228893E+08
}
